package com.musicviz.app

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.os.Bundle

class CarWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        if (AudioBus.running) return
        val pending = goAsync()
        Thread {
            try {
                Widgets.staticUpdate(context, appWidgetIds)
            } catch (e: Throwable) {
            } finally {
                pending.finish()
            }
        }.start()
    }

    override fun onAppWidgetOptionsChanged(
        context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int, newOptions: Bundle
    ) {
        if (AudioBus.running) return
        val pending = goAsync()
        Thread {
            try {
                Widgets.staticUpdate(context, intArrayOf(appWidgetId))
            } catch (e: Throwable) {
            } finally {
                pending.finish()
            }
        }.start()
    }
}
