package com.musicviz.engine;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.TreeSet;

/** 3D-сцена: ВАЗ с огромным сабом, двери/багажник/свет, программный растеризатор. */
public final class Scene3D {

    public static final int BANDS = 28;
    private static final float DG = 0.012f;           // зазор двери

    /** Доступ к файлам приложения (assets) и декодирование картинок — реализует Android-слой. */
    public interface Assets {
        java.io.InputStream open(String name) throws java.io.IOException;
        Tex decode(java.io.InputStream in) throws java.io.IOException;
    }
    public static Assets assets;
    public static final int OBJ_MODEL = 4;

    public static String[] modelNames() {
        Spec[] a = Spec.all();
        String[] r = new String[a.length + 1];
        for (int i = 0; i < a.length; i++) r[i] = a[i].name;
        r[a.length] = "BMW E30 M3 (3D-модель)";
        return r;
    }

    public static String[] paintNames() {
        return new String[]{"Чёрная", "Белая", "Тёмно-зелёная", "Серебристая", "Красная", "Синяя"};
    }

    // r, g, b, env, spec
    private static final float[][] PAINT = {
        {0.010f, 0.010f, 0.012f, 0.95f, 1.0f},
        {0.86f, 0.86f, 0.85f, 0.28f, 0.8f},
        {0.050f, 0.115f, 0.085f, 0.55f, 0.9f},
        {0.46f, 0.48f, 0.51f, 0.55f, 0.9f},
        {0.50f, 0.025f, 0.035f, 0.50f, 0.9f},
        {0.035f, 0.085f, 0.42f, 0.55f, 0.9f}};

    // ---- камера ----
    public float yaw = (float) Math.PI + 0.62f, pitch = 0.30f, dist = 6.4f;
    public float fov = 0.50f;

    // ---- переключатели ----
    public boolean headlights, cabinLight, doorsOpen, trunkOpen, hoodOpen, showBars = false, showGround = true;
    public boolean floorGlow = false, flashLights = false, subLed = true;
    public int paintIdx = 0, modelIdx = 0, requestedModel = -1;
    public float[] accent = {0f, 0.69f, 1f};
    public int viewMode;                       // 0 обзор, 1 едет по дороге, 2 из салона
    public float speedKmh = 70f;
    public boolean rain, snow;
    public float lookYaw, lookPitch;
    private float odo, spin;
    private Part roadSurface;

    // ---- анимация ----
    private float doorA, trunkA, hoodA, cabinA, headA;
    private float exc, vel, light, prevTarget, waveCd, time, sus, subPhase, subExc;
    private final float[][] heads = new float[2][3], tails = new float[2][3];
    private float[] mbody = Mat.id();
    private float[] eyeLocal = {-0.36f, 1.17f, 0.14f};
    private final ArrayList<Part> poolParts = new ArrayList<>();
    private final float[] waves = new float[6];
    private final float[] bars = new float[BANDS];
    private final float[] rawBands = new float[BANDS];
    private float bounce, shakeX, pitchB, rollB;

    // ---- модель ----
    private Spec sp;
    private final ArrayList<Part> parts = new ArrayList<>();
    private Part[] arr = new Part[0];
    private final Part[] ringParts = new Part[6];
    private final Part[] barParts = new Part[BANDS];
    private Part groundPart, beamPart, shadowPart;

    public Scene3D() {
        Arrays.fill(waves, -1f);
        setModel(0);
    }

    public void setModel(int idx) {
        requestedModel = idx;
        Spec[] all = Spec.all();
        if (idx == OBJ_MODEL && ObjCar.get(assets) != null) {
            modelIdx = OBJ_MODEL;
            sp = all[0];
            buildObj();
            return;
        }
        modelIdx = Math.max(0, Math.min(idx, all.length - 1));
        sp = all[modelIdx];
        build();
    }

    public void setViewMode(int m) {
        viewMode = m;
        if (m == 1) { yaw = (float) Math.PI + 0.30f; pitch = 0.20f; dist = 6.4f; }
        if (m == 2) { lookYaw = 0f; lookPitch = 0.03f; }
    }

    public void setPaint(int idx) { paintIdx = Math.max(0, Math.min(idx, PAINT.length - 1)); }

    public void setAccent(int argb) {
        accent[0] = ((argb >> 16) & 255) / 255f;
        accent[1] = ((argb >> 8) & 255) / 255f;
        accent[2] = (argb & 255) / 255f;
    }

    // ================= анимация =================

    public void stepDemo(float dt) {
        float t = time + dt;
        float ph = (t * 2.1333f) % 1f;
        float kick = (float) Math.exp(-ph * 5.5f);
        for (int i = 0; i < BANDS; i++) {
            float v = 0.5f * kick * (1f - i / 36f) + 0.22f * Math.abs((float) Math.sin(t * 1.6f + i * 0.65f));
            rawBands[i] = Math.max(0f, Math.min(1f, v));
        }
        step(dt, 0.8f * kick, rawBands, 1f);
    }

    public void step(float dt, float rawBass, float[] bands, float sens) {
        time += dt;
        float vms = viewMode == 0 ? 0f : Math.max(0f, speedKmh) / 3.6f;
        odo += vms * dt;
        spin += vms * dt / 0.30f;
        if (bands != rawBands) System.arraycopy(bands, 0, rawBands, 0, BANDS);
        float env = Math.max(0f, Math.min(1.25f, rawBass * sens));
        sus += (env - sus) * Math.min(1f, dt * 3.0f);
        subPhase += dt * 2f * (float) Math.PI * 14f;
        float target = env;

        float h = dt / 2f;
        for (int s = 0; s < 2; s++) {
            float acc = 720f * (target - exc) - 30f * vel;
            vel += acc * h;
            exc += vel * h;
        }
        if (exc < -0.25f) { exc = -0.25f; vel = 0f; }
        light = target > light ? Math.min(target, 1f) : Math.max(0f, light - dt * 3.2f);
        // диффузор: на коротких ударах бьёт вперёд, на длинном басе качается вперёд-назад без остановки
        float depth = Math.min(1f, sus * 1.6f);
        float swing = (float) Math.sin(subPhase) + 0.35f * (float) Math.sin(subPhase * 0.5f + 1.3f);
        subExc = exc * (1f - depth) + exc * depth * (0.10f + 0.95f * swing);
        waveCd -= dt;
        if (target - prevTarget > 0.2f && target > 0.45f && waveCd <= 0f) {
            for (int i = 0; i < waves.length; i++) if (waves[i] < 0f) { waves[i] = 0f; break; }
            waveCd = 0.22f;
        }
        prevTarget = target;
        for (int i = 0; i < waves.length; i++) {
            if (waves[i] >= 0f) { waves[i] += dt * 0.9f; if (waves[i] > 1f) waves[i] = -1f; }
        }
        for (int i = 0; i < BANDS; i++) {
            float t = Math.max(0f, Math.min(1f, rawBands[i] * sens));
            float rate = t > bars[i] ? 28f : 6f;
            bars[i] += (t - bars[i]) * (1f - (float) Math.exp(-rate * dt));
        }
        float e = Math.max(0f, Math.min(1.3f, exc));
        bounce = -e * 0.012f;
        shakeX = (float) Math.sin(time * 83f) * e * 0.0035f;
        float sp1 = Math.min(1f, vms / 28f);
        pitchB = (float) Math.sin(time * 41f) * e * 0.0016f + (float) Math.sin(time * 9.3f) * 0.0012f * sp1;
        rollB = (float) Math.sin(time * 53f) * e * 0.0018f + (float) Math.sin(time * 5.1f) * 0.0016f * sp1;

        float k = dt / 1.1f;
        doorA = move(doorA, doorsOpen ? 1f : 0f, k);
        trunkA = move(trunkA, trunkOpen ? 1f : 0f, k);
        hoodA = move(hoodA, hoodOpen ? 1f : 0f, k);
        cabinA = move(cabinA, cabinLight ? 1f : 0f, dt * 5f);
        headA = move(headA, headlights ? 1f : 0f, dt * 5f);
    }

    private static float move(float v, float t, float d) {
        if (v < t) return Math.min(t, v + d);
        return Math.max(t, v - d);
    }

    private static float smooth(float x) { return x * x * (3f - 2f * x); }

    private void updateDynamics() {
        float[] mb = Mat.mul(Mat.t(shakeX, bounce, 0f), Mat.mul(Mat.rx(pitchB), Mat.rz(rollB)));
        mbody = mb;
        float lt = Math.max(0f, Math.min(1f, light));
        float shk = 0.0045f * Math.min(1f, Math.abs(subExc));
        for (Part p : arr) {
            switch (p.group) {
                case 0: p.m = p.base; break;
                case 1:
                    p.m = Mat.mul(mb, p.base);
                    if (p.tag.equals("sub") && shk > 0f)
                        p.m = Mat.mul(Mat.t((float) Math.sin(time * 91f) * shk, (float) Math.sin(time * 77f) * shk, (float) Math.sin(time * 63f) * shk * 0.6f), p.m);
                    break;
                case 2: {
                    float amt = smooth(p.ctrl == 1 ? doorA : (p.ctrl == 3 ? hoodA : trunkA));
                    float a = amt * p.maxAng * p.dir;
                    if (p.ctrl == 2 && amt > 0.98f) a += (float) Math.sin(time * 70f) * Math.max(0f, exc) * 0.012f;
                    float[] hm = p.axis == 1 ? Mat.ry(a) : Mat.rx(a);
                    p.m = Mat.mul(mb, Mat.mul(Mat.t(p.pivot[0], p.pivot[1], p.pivot[2]), hm));
                    break;
                }
                case 6:
                    p.m = Mat.mul(Mat.t(p.pivot[0], p.pivot[1], p.pivot[2]), Mat.rx(spin));
                    break;
                case 7:
                    p.m = Mat.t(0f, 0f, -(odo % p.period));
                    break;
                default: break;
            }
            switch (p.glowKind) {
                case 11: set(p, new float[]{0.85f, 0.9f, 1f}, snow ? 0.5f : 0f); break;
                case 1: set(p, accent, subLed ? 0.55f + 0.45f * lt : 0f); break;
                case 9: set(p, accent, floorGlow ? 0.5f + 0.5f * lt : 0f); break;
                case 2: set(p, new float[]{1f, 0.07f, 0.05f}, flashLights ? 0.12f + 0.22f * headA + 1.1f * lt : 0.30f + 0.55f * headA); break;
                case 3: set(p, new float[]{1f, 0.95f, 0.80f}, 1.15f * headA); break;
                case 5: set(p, accent, floorGlow ? 0.06f + 0.55f * lt : 0f); break;
                case 7: set(p, new float[]{1f, 0.82f, 0.55f}, 0.62f * cabinA); break;
                case 8: set(p, new float[]{1f, 0.95f, 0.80f}, 0.95f * headA); break;
                default: break;
            }
        }
        if (roadSurface != null) { roadSurface.env = rain ? 0.55f : 0.12f; roadSurface.spec = rain ? 0.6f : 0.2f; }
        for (int i = 0; i < ringParts.length; i++) {
            Part p = ringParts[i];
            if (p == null) continue;
            float w = waves[i];
            boolean on = w >= 0f && showGround && floorGlow;
            p.glowAmt = on ? (1f - w) * 1.1f : 0f;
            float r = 1.4f + w * 7.5f;
            p.m = Mat.mul(Mat.t(0f, 0.012f, 0f), Mat.s(on ? r : 0.001f, 1f, on ? r : 0.001f));
            set(p, accent, p.glowAmt);
        }
        for (int i = 0; i < BANDS; i++) {
            Part p = barParts[i];
            if (p == null) continue;
            double a = 2 * Math.PI * (i + 0.5) / BANDS;
            float h = showBars && viewMode == 0 ? 0.03f + bars[i] * 0.95f : 0.0001f;
            float sc = showBars && viewMode == 0 ? 1f : 0.0001f;
            p.m = Mat.mul(Mat.t((float) Math.sin(a) * 6.4f, 0f, (float) Math.cos(a) * 6.4f),
                    Mat.mul(Mat.ry((float) a), Mat.s(sc, h, sc)));
            set(p, accent, 0.35f + 0.65f * bars[i]);
        }
    }

    private static void set(Part p, float[] c, float amt) {
        p.glowCol[0] = c[0]; p.glowCol[1] = c[1]; p.glowCol[2] = c[2];
        p.glowAmt = amt;
    }

    private Part mk(int group, float spec, float shin, float env) {
        Part p = new Part();
        p.group = group; p.spec = spec; p.shin = shin; p.env = env;
        parts.add(p);
        return p;
    }

    // ================= утилиты геометрии =================

    private static float[] f3(float x, float y, float z) { return new float[]{x, y, z}; }

    private static float[] lin(float a, float b, float step) {
        int n = Math.max(1, (int) Math.ceil(Math.abs(b - a) / step - 1e-4));
        float[] r = new float[n + 1];
        for (int i = 0; i <= n; i++) r[i] = a + (b - a) * i / n;
        return r;
    }

    private static float[] join(float[]... segs) {
        ArrayList<Float> l = new ArrayList<>();
        for (float[] s : segs) for (int i = 0; i < s.length; i++) {
            if (!l.isEmpty() && Math.abs(l.get(l.size() - 1) - s[i]) < 1e-4f) continue;
            l.add(s[i]);
        }
        float[] r = new float[l.size()];
        for (int i = 0; i < r.length; i++) r[i] = l.get(i);
        return r;
    }

    private float[] zAll() {
        TreeSet<Float> br = new TreeSet<>();
        br.add(sp.zRear()); br.add(sp.zFront());
        br.add(sp.zRoofFront); br.add(sp.zCowl); br.add(sp.zHinge); br.add(sp.zRoofRear);
        br.add(sp.zs[1]);
        for (float[] d : sp.doors) { br.add(d[0]); br.add(d[1]); }
        Float[] b = br.toArray(new Float[0]);
        float[][] segs = new float[b.length - 1][];
        for (int i = 0; i < b.length - 1; i++) segs[i] = lin(b[i], b[i + 1], 0.06f);
        return join(segs);
    }

    private float[][][] surf(float[] zs, float[] ss, int sign) {
        float[][][] p = new float[zs.length][ss.length][];
        for (int i = 0; i < zs.length; i++)
            for (int j = 0; j < ss.length; j++) {
                float[] q = sp.prof(zs[i], ss[j]);
                p[i][j] = f3(sign * q[0], q[1], zs[i]);
            }
        return p;
    }

    private interface Cell { boolean skip(float zc, float sc, float xc, float yc); }

    private static boolean[][] skipArr(float[] zs, float[] ss, float[][][] p, Cell c) {
        boolean[][] sk = new boolean[zs.length - 1][ss.length - 1];
        for (int i = 0; i < zs.length - 1; i++)
            for (int j = 0; j < ss.length - 1; j++) {
                float xc = (p[i][j][0] + p[i+1][j+1][0]) * 0.5f, yc = (p[i][j][1] + p[i+1][j+1][1]) * 0.5f;
                sk[i][j] = c.skip((zs[i] + zs[i+1]) * 0.5f, (ss[j] + ss[j+1]) * 0.5f, xc, yc);
            }
        return sk;
    }

    /** Нормали сетки (как в Part.grid) и смещённая копия: p - d*n. */
    private static float[][][] offset(float[][][] p, boolean flip, float d) {
        int nu = p.length, nv = p[0].length;
        float[][][] r = new float[nu][nv][3];
        for (int i = 0; i < nu; i++)
            for (int j = 0; j < nv; j++) {
                int i0 = Math.max(i - 1, 0), i1 = Math.min(i + 1, nu - 1), j0 = Math.max(j - 1, 0), j1 = Math.min(j + 1, nv - 1);
                float ux = p[i1][j][0]-p[i0][j][0], uy = p[i1][j][1]-p[i0][j][1], uz = p[i1][j][2]-p[i0][j][2];
                float vx = p[i][j1][0]-p[i][j0][0], vy = p[i][j1][1]-p[i][j0][1], vz = p[i][j1][2]-p[i][j0][2];
                float nx, ny, nz;
                if (flip) { nx = vy*uz - vz*uy; ny = vz*ux - vx*uz; nz = vx*uy - vy*ux; }
                else      { nx = uy*vz - uz*vy; ny = uz*vx - ux*vz; nz = ux*vy - uy*vx; }
                float l = (float) Math.sqrt(nx*nx + ny*ny + nz*nz);
                if (l < 1e-12f) l = 1f;
                r[i][j][0] = p[i][j][0] - d * nx / l; r[i][j][1] = p[i][j][1] - d * ny / l; r[i][j][2] = p[i][j][2] - d * nz / l;
            }
        return r;
    }

    private static float[][][] sub(float[][][] p, int i0, int i1, int j0, int j1) {
        float[][][] r = new float[i1 - i0 + 1][j1 - j0 + 1][];
        for (int i = i0; i <= i1; i++) for (int j = j0; j <= j1; j++) r[i - i0][j - j0] = p[i][j].clone();
        return r;
    }

    private static void shiftGrid(float[][][] p, float dx, float dy, float dz) {
        for (float[][] row : p) for (float[] q : row) { q[0] += dx; q[1] += dy; q[2] += dz; }
    }

    private static int idxGE(float[] a, float v) { for (int i = 0; i < a.length; i++) if (a[i] >= v - 1e-4f) return i; return a.length - 1; }
    private static int idxLE(float[] a, float v) { for (int i = a.length - 1; i >= 0; i--) if (a[i] <= v + 1e-4f) return i; return 0; }

    // ================= сборка модели =================

    private static final float[] BLK = {0.018f, 0.018f, 0.020f}, DGRAY = {0.075f, 0.075f, 0.080f},
        CARP = {0.035f, 0.035f, 0.040f}, GLS = {0.020f, 0.030f, 0.045f}, CHR = {0.78f, 0.80f, 0.83f},
        WHT = {1f, 1f, 1f}, SEAT = {0.30f, 0.285f, 0.26f}, LINER = {0.22f, 0.21f, 0.19f},
        ROOFC = {0.50f, 0.48f, 0.44f}, DASH = {0.07f, 0.07f, 0.075f}, REDC = {0.26f, 0.018f, 0.025f},
        AMB = {0.60f, 0.28f, 0.04f}, PLT = {0.93f, 0.93f, 0.90f}, ASPH = {0.040f, 0.042f, 0.050f};

    private void build() {
        parts.clear();
        Arrays.fill(ringParts, null);
        Arrays.fill(barParts, null);
        buildBody();
        buildDoors();
        buildRear();
        buildInterior();
        buildCargo();
        buildWheels();
        buildDetails();
        buildWorld();
        buildRoad();
        eyeLocal = new float[]{-0.36f, 1.17f, 0.14f};
        arr = parts.toArray(new Part[0]);
    }

    private boolean inDoor(float zc, float sc, float s0, float s1) {
        if (sc < s0 || sc > s1) return false;
        for (float[] d : sp.doors) if (zc >= d[0] && zc <= d[1]) return true;
        return false;
    }

    private static boolean arch(float zc, float yc, float wz) {
        float dz = zc - wz, dy = yc - 0.29f;
        return dz * dz + dy * dy < 0.34f * 0.34f;
    }

    private float hwAtY(float z, float y) {
        float[] prev = sp.prof(z, 0f);
        if (prev[1] >= y) return prev[0];
        for (float s = 0.05f; s <= 3.001f; s += 0.05f) {
            float[] q = sp.prof(z, s);
            if (q[1] >= y) {
                float t = (y - prev[1]) / Math.max(1e-5f, q[1] - prev[1]);
                return prev[0] + (q[0] - prev[0]) * t;
            }
            prev = q;
        }
        return prev[0];
    }

    /** Полигон сечения кузова на плоскости z, обрезанный по высоте. */
    private ArrayList<float[]> capPoly(float z, float yMin, float yMax) {
        ArrayList<float[]> poly = new ArrayList<>();
        for (float s = 0f; s <= 6.001f; s += 0.2f) { float[] q = sp.prof(z, s); poly.add(new float[]{q[0], q[1]}); }
        for (float s = 6f; s >= -0.001f; s -= 0.2f) { float[] q = sp.prof(z, Math.max(0f, s)); poly.add(new float[]{-q[0], q[1]}); }
        poly = clipY(poly, yMin, true);
        poly = clipY(poly, yMax, false);
        return poly;
    }

    private static ArrayList<float[]> clipY(ArrayList<float[]> in, float lim, boolean keepAbove) {
        ArrayList<float[]> out = new ArrayList<>();
        int n = in.size();
        for (int i = 0; i < n; i++) {
            float[] a = in.get(i), b = in.get((i + 1) % n);
            boolean ai = keepAbove ? a[1] >= lim : a[1] <= lim, bi = keepAbove ? b[1] >= lim : b[1] <= lim;
            if (ai) out.add(a);
            if (ai != bi) {
                float t = (lim - a[1]) / (b[1] - a[1]);
                out.add(new float[]{a[0] + (b[0] - a[0]) * t, lim});
            }
        }
        return out;
    }

    private void fanCap(Part p, ArrayList<float[]> poly, float z, float nz, float[] rgb) {
        if (poly.size() < 3) return;
        float cx = 0, cy = 0;
        for (float[] q : poly) { cx += q[0]; cy += q[1]; }
        cx /= poly.size(); cy /= poly.size();
        int c = p.vtx(cx, cy, z, 0, 0, nz, rgb[0], rgb[1], rgb[2], 0, 0);
        int first = -1, prev = -1;
        for (float[] q : poly) {
            int v = p.vtx(q[0], q[1], z, 0, 0, nz, rgb[0], rgb[1], rgb[2], 0, 0);
            if (prev >= 0) p.tri(c, prev, v); else first = v;
            prev = v;
        }
        p.tri(c, prev, first);
    }

    private void ribbons(Part rp, float[][][] a, float[][][] b) {
        int nu = a.length, nv = a[0].length;
        float[] k = BLK;
        for (int i = 0; i < nu - 1; i++) {
            rp.quad(a[i][0], a[i+1][0], b[i+1][0], b[i][0], k);
            rp.quad(a[i][nv-1], a[i+1][nv-1], b[i+1][nv-1], b[i][nv-1], k);
        }
        for (int j = 0; j < nv - 1; j++) {
            rp.quad(a[0][j], a[0][j+1], b[0][j+1], b[0][j], k);
            rp.quad(a[nu-1][j], a[nu-1][j+1], b[nu-1][j+1], b[nu-1][j], k);
        }
    }

    private Part twoSided(Part p) { p.twoSided = true; return p; }

    // ---------- кузов ----------
    private void buildBody() {
        float[] zs = zAll();
        float[] ssA = lin(0f, 1f, 0.25f), ssB = lin(1f, 3f, 0.25f);
        float[] ssU = {3f, 3.1f, 3.3f, 3.5f, 3.7f, 3.95f, 4.0f, 4.15f, 4.35f, 4.6f, 4.8f, 5.0f, 5.25f, 5.5f, 5.75f, 6.0f};
        Part paint = mk(1, 0.9f, 60f, 0.5f); paint.paint = true;
        Part skirt = mk(1, 0.15f, 20f, 0.08f);
        Part glass = mk(1, 1f, 90f, 0.9f); glass.alpha = 0.50f;
        Part capP = twoSided(mk(1, 0.9f, 60f, 0.5f)); capP.paint = true;
        Part under = twoSided(mk(1, 0.05f, 10f, 0f));
        final float zH = sp.zHinge;
        final boolean hatch = sp.hatch;
        final float wf = sp.wheelZF, wr = sp.wheelZR;

        for (int sg = 1; sg >= -1; sg -= 2) {
            boolean flip = sg > 0;
            float[][][] pA = surf(zs, ssA, sg), pB = surf(zs, ssB, sg), pU = surf(zs, ssU, sg);
            skirt.grid(pA, flip, skipArr(zs, ssA, pA, (zc, sc, xc, yc) -> arch(zc, yc, wf) || arch(zc, yc, wr)), BLK);
            paint.grid(pB, flip, skipArr(zs, ssB, pB, (zc, sc, xc, yc) -> arch(zc, yc, wf) || arch(zc, yc, wr) || inDoor(zc, sc, 1.0f, 3.0f)), WHT);
            paint.grid(pU, flip, skipArr(zs, ssU, pU, (zc, sc, xc, yc) -> {
                if (inDoor(zc, sc, 3.0f, 4.0f)) return true;
                if (hatch && zc < zH && sc >= 4.0f) return true;
                if (!hatch && zc > sp.zs[1] && zc < zH && sc > 5.0f) return true;
                if (zc > sp.zRoofFront && zc < sp.zCowl && sc >= 4.6f) return true;
                if (!hatch && zc > zH && zc < sp.zRoofRear && sc >= 4.6f) return true;
                return false;
            }), WHT);
            int j46 = idxGE(ssU, 4.6f);
            int a0 = idxGE(zs, sp.zRoofFront), a1 = idxLE(zs, sp.zCowl);
            glass.grid(sub(pU, a0, a1, j46, ssU.length - 1), flip, null, GLS);
            if (!hatch) {
                int b0 = idxGE(zs, zH), b1 = idxLE(zs, sp.zRoofRear);
                glass.grid(sub(pU, b0, b1, j46, ssU.length - 1), flip, null, GLS);
            }
        }
        // днище
        float[][][] pu = new float[zs.length][2][];
        for (int i = 0; i < zs.length; i++) {
            float[] q = sp.prof(zs[i], 0f);
            pu[i][0] = f3(-q[0], q[1], zs[i]); pu[i][1] = f3(q[0], q[1], zs[i]);
        }
        under.grid(pu, false, null, BLK);
        // торцы
        float yCut = hatch ? sp.sill : 9f;
        fanCap(capP, capPoly(sp.zRear(), -9f, yCut), sp.zRear(), -1f, WHT);
        fanCap(capP, capPoly(sp.zFront(), -9f, 9f), sp.zFront(), 1f, WHT);
    }

    // ---------- двери ----------
    private void buildDoors() {
        for (int sg = 1; sg >= -1; sg -= 2)
            for (int di = 0; di < sp.doors.length; di++) buildDoor(sg, di);
    }

    private void buildDoor(int sg, int di) {
        boolean flip = sg > 0;
        float zr = sp.doors[di][0] + DG, zf = sp.doors[di][1] - DG;
        float[] zsD = lin(zr, zf, 0.05f);
        float[] ssD = {1.04f, 1.25f, 1.5f, 1.75f, 2.0f, 2.25f, 2.5f, 2.75f, 3.0f, 3.12f, 3.2f, 3.4f, 3.6f, 3.8f, 3.92f, 3.98f};
        float[][][] po = surf(zsD, ssD, sg);
        float[][][] pi = offset(po, flip, 0.075f);
        float px = sg * sp.prof(zf, 2.0f)[0], pz = zf;
        shiftGrid(po, -px, 0f, -pz);
        shiftGrid(pi, -px, 0f, -pz);

        int gi0 = idxGE(zsD, zr + 0.07f), gi1 = idxLE(zsD, zf - 0.07f), js0 = 10, js1 = 14;
        boolean[][] sk = new boolean[zsD.length - 1][ssD.length - 1];
        for (int i = gi0; i < gi1; i++) for (int j = js0; j < js1; j++) sk[i][j] = true;

        Part dp = mk(2, 0.9f, 60f, 0.5f); dp.paint = true;
        Part dg = mk(2, 1f, 90f, 0.9f); dg.alpha = 0.50f;
        Part dl = mk(2, 0.06f, 12f, 0.02f);
        Part dt = twoSided(mk(2, 0.25f, 20f, 0.1f));
        Part ds = mk(2, 0.5f, 30f, 0.3f);
        Part[] dd = {dp, dg, dl, dt, ds};
        for (Part p : dd) {
            p.axis = 1; p.ctrl = 1; p.maxAng = (di == 0 ? 62f : 58f) * (float) Math.PI / 180f; p.dir = -sg;
            p.pivot[0] = px; p.pivot[1] = 0f; p.pivot[2] = pz;
        }
        dp.grid(po, flip, sk, WHT);
        dg.grid(sub(po, gi0, gi1, js0, js1), flip, null, GLS);
        dl.grid(pi, !flip, null, LINER);
        ribbons(dt, po, pi);
        // ручка и зеркало
        float zmid = (zr + zf) * 0.5f;
        float hx = sg * (hwAtY(zr + 0.14f, 0.88f) + 0.010f) - px;
        dt.box(hx, 0.88f, zr + 0.14f - pz, 0.012f, 0.014f, 0.055f, BLK, 0f, 0f);
        if (di == 0) {
            float mx = sg * (hwAtY(zf, 1.0f) + 0.07f) - px;
            dt.box(mx, 1.04f, zf - 0.16f - pz, 0.05f, 0.036f, 0.06f, BLK, 0f, 0f);
            dt.box(sg * (hwAtY(zf, 1.0f) + 0.015f) - px, 1.0f, zf - 0.12f - pz, 0.05f, 0.01f, 0.015f, BLK, 0f, 0f);
        }
        // динамик в двери
        float sx = sg * (hwAtY(zmid, 0.6f) - 0.075f - 0.004f) - px;
        float[] M = Mat.mul(Mat.t(sx, 0.60f, zr + 0.26f - pz), Mat.ry(-sg * (float) Math.PI / 2f));
        int v1 = ds.nv;
        ds.revolve(new float[][]{{0.095f, 0.002f, 0, 0}, {0.088f, 0.012f, 0, 0}, {0.074f, 0.010f, 0, 0}, {0.060f, -0.004f, 0, 0},
                {0.024f, -0.014f, 0, 0}, {0.0f, -0.006f, 0, 0}}, 24, false, DGRAY);
        ds.xform(v1, M);
        dl.glowByPoint(-px, 1.3f, -pz, 2.2f, 0.2f);
        dl.glowKind = 7;
    }

    // ---------- крышка багажника / пятая дверь ----------
    private void buildRear() {
        final float zH = sp.zHinge;
        final float yH = sp.pt(6, zH)[1];
        Part lp = mk(2, 0.9f, 60f, 0.5f); lp.paint = true;
        Part lg = mk(2, 1f, 90f, 0.9f); lg.alpha = 0.5f;
        Part ll = mk(2, 0.05f, 10f, 0.02f);
        Part lt = twoSided(mk(2, 0.25f, 20f, 0.1f));
        Part lcap = twoSided(mk(2, 0.9f, 60f, 0.5f)); lcap.paint = true;
        Part lcin = twoSided(mk(2, 0.05f, 10f, 0.02f));
        Part lamp = mk(2, 0.5f, 20f, 0.1f);
        Part[] all = {lp, lg, ll, lt, lcap, lcin, lamp};
        for (Part p : all) {
            p.axis = 2; p.ctrl = 2; p.pivot[0] = 0f; p.pivot[1] = yH; p.pivot[2] = zH;
            p.maxAng = (sp.hatch ? 108f : 70f) * (float) Math.PI / 180f; p.dir = 1f;
        }
        if (!sp.hatch) {
            float[] zl = lin(sp.zs[1], zH, 0.06f);
            float[] sl = lin(5f, 6f, 0.125f);
            for (int sg = 1; sg >= -1; sg -= 2) {
                boolean flip = sg > 0;
                float[][][] p = surf(zl, sl, sg);
                float[][][] q = offset(p, flip, 0.045f);
                shiftGrid(p, 0f, -yH, -zH); shiftGrid(q, 0f, -yH, -zH);
                lp.grid(p, flip, null, WHT);
                ll.grid(q, !flip, null, new float[]{0.06f, 0.06f, 0.065f});
                ribbons(lt, p, q);
            }
        } else {
            float[] zr = lin(sp.zRear(), zH, 0.05f);
            float[] st = {4.0f, 4.15f, 4.35f, 4.6f, 4.8f, 5.0f, 5.25f, 5.5f, 5.75f, 6.0f};
            int g0 = idxGE(zr, sp.zRear() + 0.10f), g1 = idxLE(zr, zH - 0.04f), j0 = 3;
            for (int sg = 1; sg >= -1; sg -= 2) {
                boolean flip = sg > 0;
                float[][][] p = surf(zr, st, sg);
                float[][][] q = offset(p, flip, 0.05f);
                shiftGrid(p, 0f, -yH, -zH); shiftGrid(q, 0f, -yH, -zH);
                boolean[][] sk = new boolean[zr.length - 1][st.length - 1];
                for (int i = g0; i < g1; i++) for (int j = j0; j < st.length - 1; j++) sk[i][j] = true;
                lp.grid(p, flip, sk, WHT);
                lg.grid(sub(p, g0, g1, j0, st.length - 1), flip, null, GLS);
                ll.grid(q, !flip, null, new float[]{0.07f, 0.07f, 0.075f});
                ribbons(lt, p, q);
            }
            int vsp = lp.nv;
            lp.box(0f, 0.018f, -0.15f, 0.50f, 0.014f, 0.10f, WHT, 0f, 0f);
            lp.xform(vsp, aboutPoint(0f, 0.018f, -0.15f, Mat.rx(0.04f)));
            // нижняя панель двери
            ArrayList<float[]> poly = capPoly(sp.zRear(), sp.sill, 9f);
            float z0 = sp.zRear() - zH;
            ArrayList<float[]> shifted = new ArrayList<>();
            for (float[] q : poly) shifted.add(new float[]{q[0], q[1] - yH});
            fanCap(lcap, shifted, z0, -1f, WHT);
            fanCap(lcin, shifted, z0 + 0.05f, 1f, new float[]{0.07f, 0.07f, 0.075f});
            // лампочки на двери
            lamp.box(-0.45f, sp.sill - yH + 0.07f, z0 + 0.06f, 0.055f, 0.012f, 0.02f, new float[]{0.8f, 0.8f, 0.78f}, 1f, 1f);
            lamp.box(0.45f, sp.sill - yH + 0.07f, z0 + 0.06f, 0.055f, 0.012f, 0.02f, new float[]{0.8f, 0.8f, 0.78f}, 1f, 1f);
            for (int i = 0; i < lamp.nv; i++) lamp.gw[i] = 2.4f;
            lamp.glowKind = 7;
        }
    }

    // ---------- вспомогательное ----------
    private static float[] basisZ(float ux, float uy, float uz) {
        float l = (float) Math.sqrt(ux*ux + uy*uy + uz*uz);
        ux /= l; uy /= l; uz /= l;
        float xx = uz, xy = 0f, xz = -ux;
        float xl = (float) Math.sqrt(xx*xx + xz*xz);
        if (xl < 1e-5f) { xx = 1f; xz = 0f; xl = 1f; }
        xx /= xl; xz /= xl;
        float yx = uy*xz - uz*xy, yy = uz*xx - ux*xz, yz = ux*xy - uy*xx;
        return new float[]{xx, yx, ux, 0, xy, yy, uy, 0, xz, yz, uz, 0, 0, 0, 0, 1};
    }

    private static float[] aboutPoint(float cx, float cy, float cz, float[] r) {
        return Mat.mul(Mat.t(cx, cy, cz), Mat.mul(r, Mat.t(-cx, -cy, -cz)));
    }

    private static float[] apply(float[] M, float x, float y, float z) {
        return f3(M[0]*x + M[1]*y + M[2]*z + M[3], M[4]*x + M[5]*y + M[6]*z + M[7], M[8]*x + M[9]*y + M[10]*z + M[11]);
    }

    // ---------- салон ----------
    private void seat(Part s, float cx, float cz) {
        s.box(cx, 0.45f, cz, 0.23f, 0.07f, 0.24f, SEAT, 0f, 0f);
        s.box(cx - 0.20f, 0.50f, cz, 0.03f, 0.09f, 0.22f, SEAT, 0f, 0f);
        s.box(cx + 0.20f, 0.50f, cz, 0.03f, 0.09f, 0.22f, SEAT, 0f, 0f);
        int v1 = s.nv;
        s.box(cx, 0.83f, cz - 0.21f, 0.22f, 0.31f, 0.065f, SEAT, 0f, 0f);
        s.xform(v1, aboutPoint(cx, 0.52f, cz - 0.2f, Mat.rx(-0.2f)));
        int v2 = s.nv;
        s.box(cx, 1.22f, cz - 0.27f, 0.10f, 0.07f, 0.05f, SEAT, 0f, 0f);
        s.xform(v2, aboutPoint(cx, 0.52f, cz - 0.2f, Mat.rx(-0.2f)));
    }

    private void buildInterior() {
        boolean h = sp.hatch;
        float zA = h ? sp.zRear() + 0.03f : sp.zHinge + 0.02f, zB = sp.zCowl + 0.02f;
        Part shell = mk(1, 0.05f, 10f, 0.02f), roofP = mk(1, 0.05f, 10f, 0.02f);
        Part carpet = twoSided(mk(1, 0.02f, 8f, 0f)), seats = mk(1, 0.08f, 12f, 0.02f);
        Part dash = mk(1, 0.35f, 25f, 0.15f), dome = mk(1, 0.3f, 20f, 0.1f);
        float[] zi = lin(zA, zB, 0.12f);
        float[] zr = lin(h ? sp.zHinge : zA, zB, 0.12f);
        float[] ssW = lin(1.0f, 4.3f, 0.4f), ssR = lin(4.3f, 6f, 0.43f);
        for (int sg = 1; sg >= -1; sg -= 2) {
            boolean flip = sg > 0;
            shell.grid(offset(surf(zi, ssW, sg), flip, 0.07f), !flip, null, LINER);
            roofP.grid(offset(surf(zr, ssR, sg), flip, 0.07f), !flip, null, ROOFC);
        }
        // пол
        float zf0 = h ? -0.72f : sp.zHinge + 0.02f;
        carpet.quad(f3(-0.66f, 0.34f, zf0), f3(0.66f, 0.34f, zf0), f3(0.66f, 0.34f, zB - 0.1f), f3(-0.66f, 0.34f, zB - 0.1f), CARP);
        // сиденья
        float fz = 0.20f, rz = -0.58f;
        seat(seats, -0.36f, fz);
        seat(seats, 0.36f, fz);
        seats.box(0f, 0.45f, rz, 0.62f, 0.07f, 0.24f, SEAT, 0f, 0f);
        int v1 = seats.nv;
        seats.box(0f, 0.83f, rz - 0.21f, 0.62f, 0.31f, 0.065f, SEAT, 0f, 0f);
        seats.xform(v1, aboutPoint(0f, 0.52f, rz - 0.2f, Mat.rx(-0.2f)));
        for (int i = -1; i <= 1; i++) {
            int v2 = seats.nv;
            seats.box(i * 0.38f, 1.22f, rz - 0.27f, 0.10f, 0.07f, 0.05f, SEAT, 0f, 0f);
            seats.xform(v2, aboutPoint(0f, 0.52f, rz - 0.2f, Mat.rx(-0.2f)));
        }
        // торпедо
        dash.box(0f, 0.66f, 0.74f, 0.74f, 0.22f, 0.20f, DASH, 0f, 0f);
        dash.box(-0.36f, 0.93f, 0.62f, 0.20f, 0.05f, 0.10f, DASH, 0f, 0f);
        dash.box(0f, 0.52f, 0.46f, 0.10f, 0.20f, 0.10f, DASH, 0f, 0f);
        dash.box(0f, 0.44f, 0.10f, 0.05f, 0.08f, 0.22f, DASH, 0f, 0f);
        // руль
        float[][] tor = new float[13][];
        for (int i = 0; i <= 12; i++) {
            double t = 2 * Math.PI * i / 12;
            tor[i] = new float[]{0.17f + 0.016f * (float) Math.cos(t), 0.016f * (float) Math.sin(t), 0f, 0f};
        }
        int vw = dash.nv;
        dash.revolve(tor, 28, false, BLK);
        dash.box(0f, 0f, 0f, 0.045f, 0.045f, 0.012f, BLK, 0f, 0f);
        dash.xform(vw, Mat.mul(Mat.t(-0.36f, 0.86f, 0.46f), basisZ(0f, 0.40f, -0.92f)));
        int vc = dash.nv;
        dash.box(0f, 0f, 0.14f, 0.022f, 0.022f, 0.16f, BLK, 0f, 0f);
        dash.xform(vc, Mat.mul(Mat.t(-0.36f, 0.76f, 0.54f), basisZ(0f, 0.40f, -0.92f)));
        // плафон
        dome.box(0f, 1.345f, -0.05f, 0.07f, 0.010f, 0.05f, new float[]{0.8f, 0.8f, 0.78f}, 1f, 1f);
        for (int i = 0; i < dome.nv; i++) dome.gw[i] = 2.6f;
        dome.glowKind = 7;
        // полка (седан)
        if (!h) {
            float yS = sp.pt(6, sp.zHinge)[1] - 0.05f;
            carpet.quad(f3(-0.62f, yS, sp.zHinge + 0.02f), f3(0.62f, yS, sp.zHinge + 0.02f), f3(0.62f, yS + 0.02f, -0.74f), f3(-0.62f, yS + 0.02f, -0.74f), DGRAY);
            for (int sg = -1; sg <= 1; sg += 2) {
                int vs = seats.nv;
                seats.revolve(new float[][]{{0.10f, 0f, 0, 0}, {0.092f, 0.012f, 0, 0}, {0.07f, 0.008f, 0, 0}, {0.03f, -0.012f, 0, 0}, {0f, -0.004f, 0, 0}}, 24, false, BLK);
                seats.xform(vs, Mat.mul(Mat.t(sg * 0.36f, yS + 0.02f, -0.98f), basisZ(0f, 1f, 0.12f)));
            }
        }
        for (Part p : new Part[]{shell, roofP, carpet, seats, dash}) {
            p.glowByPoint(0f, 1.30f, -0.05f, 1.9f, 0.16f);
            p.glowKind = 7;
        }
    }

    // ---------- багажник и саб ----------
    private void buildCargo() {
        Part cp = twoSided(mk(1, 0.02f, 8f, 0f));
        float cf = sp.cargoFloor;
        if (sp.hatch) {
            float z0 = sp.zRear() + 0.03f, z1 = -0.72f;
            cp.quad(f3(-0.66f, cf, z0), f3(0.66f, cf, z0), f3(0.66f, cf, z1), f3(-0.66f, cf, z1), CARP);
            for (int sg = -1; sg <= 1; sg += 2) cp.box(sg * 0.63f, cf + 0.09f, sp.wheelZR, 0.07f, 0.09f, 0.30f, CARP, 0f, 0f);
            buildSubAssembly(0f, 1.03f, -1.40f, 90f, 0.50f, 0.43f, cf, 0.31f);
            cp.glowByPoint(0f, 1.30f, -0.05f, 2.4f, 0.10f);
            cp.glowKind = 7;
        } else {
            float z0 = sp.zs[1] + 0.02f, z1 = sp.zHinge - 0.02f, yT = 0.97f;
            cp.quad(f3(-0.61f, cf, z0), f3(0.61f, cf, z0), f3(0.61f, cf, z1), f3(-0.61f, cf, z1), CARP);
            cp.quad(f3(-0.61f, cf, z0), f3(-0.61f, yT, z0), f3(-0.61f, yT, z1), f3(-0.61f, cf, z1), CARP);
            cp.quad(f3(0.61f, cf, z0), f3(0.61f, yT, z0), f3(0.61f, yT, z1), f3(0.61f, cf, z1), CARP);
            cp.quad(f3(-0.61f, cf, z0), f3(0.61f, cf, z0), f3(0.61f, yT, z0), f3(-0.61f, yT, z0), CARP);
            cp.quad(f3(-0.61f, cf, z1), f3(0.61f, cf, z1), f3(0.61f, yT, z1), f3(-0.61f, yT, z1), CARP);
            buildSubAssembly(0f, 0.84f, -1.56f, 40f, 0.50f, 0.42f, cf, 0.29f);
        }
    }

    private void buildSubAssembly(float cx, float cy, float cz, float alphaDeg, float hx, float hl, float floorY, float R) {
        float a = alphaDeg * (float) Math.PI / 180f, sa = (float) Math.sin(a), ca = (float) Math.cos(a);
        float[] base = Mat.mul(Mat.t(cx, cy, cz), basisZ(0f, sa, -ca));
        float k = R / 0.30f;

        // плита с отверстием
        Part plate = twoSided(mk(1, 0.04f, 8f, 0f));
        plate.base = base;
        int seg = 96, rows = 6;
        float rH = R * 0.95f;
        float[][][] p = new float[seg + 1][rows][3];
        for (int i = 0; i <= seg; i++) {
            double th = 2 * Math.PI * i / seg;
            float c = (float) Math.cos(th), s = (float) Math.sin(th);
            float tx = Math.abs(c) < 1e-5f ? 1e9f : hx / Math.abs(c), ty = Math.abs(s) < 1e-5f ? 1e9f : hl / Math.abs(s);
            float tr = Math.min(tx, ty);
            for (int j = 0; j < rows; j++) {
                float r = rH + (tr - rH) * j / (rows - 1);
                p[i][j] = f3(r * c, r * s, 0f);
            }
        }
        plate.grid(p, true, false, null, new float[]{0.14f, 0.14f, 0.15f}, null, null);
        // стенки колодца и дно
        Part well = twoSided(mk(1, 0.02f, 8f, 0f));
        well.base = base;
        well.revolve(new float[][]{{rH, 0f, 0, 0}, {rH, -0.25f, 0, 0}, {0.001f, -0.25f, 0, 0}}, 40, false, BLK);
        // боковые стенки короба
        Part sides = twoSided(mk(1, 0.02f, 8f, 0f));
        float[][] corner = {{hx, hl}, {-hx, hl}, {-hx, -hl}, {hx, -hl}};
        for (int i = 0; i < 4; i++) {
            float[] c0 = corner[i], c1 = corner[(i + 1) % 4];
            float[] b0 = apply(base, c0[0], c0[1], 0f), b1 = apply(base, c1[0], c1[1], 0f);
            sides.quad(b0, b1, f3(b1[0], floorY, b1[2]), f3(b0[0], floorY, b0[2]), new float[]{0.12f, 0.12f, 0.13f});
        }
        // светодиодные полосы по краю плиты
        Part led = mk(1, 0.3f, 20f, 0.1f);
        led.base = base; led.glowKind = 1;
        led.box(hx - 0.03f, 0f, 0.004f, 0.009f, hl - 0.05f, 0.003f, new float[]{0.1f, 0.1f, 0.1f}, 1f, 1f);
        led.box(-hx + 0.03f, 0f, 0.004f, 0.009f, hl - 0.05f, 0.003f, new float[]{0.1f, 0.1f, 0.1f}, 1f, 1f);
        for (int i = 0; i < led.nv; i++) led.gw[i] = 1f;

        // сам саб
        Part flange = mk(1, 0.8f, 55f, 0.45f), cap = mk(1, 0.6f, 40f, 0.25f), cone = mk(1, 0.2f, 18f, 0.06f),
             sur = mk(1, 0.1f, 10f, 0.04f), ring = mk(1, 0.5f, 30f, 0.2f);
        for (Part q : new Part[]{flange, cap, cone, sur, ring}) q.base = base;
        for (Part q : new Part[]{plate, well, sides, led, flange, cap, cone, sur, ring}) q.tag = "sub";
        cap.deform = 1; cone.deform = 1; sur.deform = 1;
        ring.glowKind = 1;
        flange.revolve(new float[][]{{0.318f*k, 0f, 0, 0}, {0.318f*k, 0.014f*k, 0, 0}, {0.262f*k, 0.014f*k, 0, 0}, {0.262f*k, 0.010f*k, 0, 0}},
                56, false, new float[]{0.40f, 0.41f, 0.44f});
        for (int i = 0; i < 8; i++) {
            double t = i * Math.PI / 4 + Math.PI / 8;
            flange.box((float) Math.cos(t) * 0.29f * k, (float) Math.sin(t) * 0.29f * k, 0.016f * k, 0.010f * k, 0.010f * k, 0.004f * k,
                    new float[]{0.8f, 0.82f, 0.85f}, 0f, 0f);
        }
        sur.revolve(new float[][]{{0.262f*k, 0.010f*k, 0, 0}, {0.250f*k, 0.032f*k, 0.15f, 0}, {0.232f*k, 0.044f*k, 0.45f, 0},
                {0.214f*k, 0.036f*k, 0.8f, 0}, {0.205f*k, 0.018f*k, 1f, 0}}, 56, false, new float[]{0.03f, 0.03f, 0.033f});
        cone.revolve(new float[][]{{0.205f*k, 0.018f*k, 1f, 0}, {0.17f*k, 0.004f*k, 1f, 0}, {0.12f*k, -0.018f*k, 1f, 0}, {0.075f*k, -0.040f*k, 1f, 0}},
                56, false, new float[]{0.13f, 0.13f, 0.145f});
        cap.revolve(new float[][]{{0.075f*k, -0.040f*k, 1f, 0}, {0.074f*k, -0.026f*k, 1f, 0}, {0.062f*k, -0.012f*k, 1f, 0},
                {0.04f*k, -0.002f*k, 1f, 0}, {0f, 0.004f*k, 1f, 0}}, 40, false, new float[]{0.30f, 0.31f, 0.34f});
        float[][] tor = new float[13][];
        for (int i = 0; i <= 12; i++) {
            double t = 2 * Math.PI * i / 12;
            tor[i] = new float[]{0.340f * k + 0.013f * k * (float) Math.cos(t), 0.006f * k + 0.013f * k * (float) Math.sin(t), 0f, 1f};
        }
        ring.revolve(tor, 64, false, new float[]{0.1f, 0.1f, 0.1f});
    }

    // ---------- колёса ----------
    private void buildWheels() {
        Part well = twoSided(mk(1, 0.02f, 8f, 0f)), trim = twoSided(mk(1, 0.15f, 15f, 0.05f));
        float[] ws = {sp.wheelZF, sp.wheelZR};
        for (int sg = 1; sg >= -1; sg -= 2)
            for (float wz : ws) {
                float cx0 = sg * sp.wheelX;
                float[] B = Mat.mul(Mat.t(cx0, 0.29f, wz), Mat.ry(sg > 0 ? (float) Math.PI / 2 : -(float) Math.PI / 2));
                Part tire = mk(6, 0.10f, 14f, 0.03f), rim = mk(6, 0.95f, 55f, 0.75f), dish = mk(6, 0.5f, 30f, 0.3f);
                tire.revolve(new float[][]{{0.19f, -0.085f, 0, 0}, {0.24f, -0.089f, 0, 0}, {0.282f, -0.076f, 0, 0}, {0.292f, -0.046f, 0, 0},
                        {0.295f, 0f, 0, 0}, {0.292f, 0.046f, 0, 0}, {0.282f, 0.076f, 0, 0}, {0.24f, 0.089f, 0, 0}, {0.19f, 0.085f, 0, 0}},
                        40, false, new float[]{0.03f, 0.03f, 0.032f});
                tire.xform(0, B);
                dish.revolve(new float[][]{{0.19f, 0.080f, 0, 0}, {0.186f, 0.060f, 0, 0}, {0.15f, 0.048f, 0, 0}, {0.09f, 0.044f, 0, 0},
                        {0.045f, 0.052f, 0, 0}, {0f, 0.056f, 0, 0}}, 36, false, new float[]{0.16f, 0.16f, 0.175f});
                dish.xform(0, B);
                rim.revolve(new float[][]{{0.196f, 0.070f, 0, 0}, {0.196f, 0.083f, 0, 0}, {0.186f, 0.086f, 0, 0}}, 36, false, new float[]{0.7f, 0.72f, 0.75f});
                rim.revolve(new float[][]{{0.05f, 0.056f, 0, 0}, {0.045f, 0.068f, 0, 0}, {0f, 0.070f, 0, 0}}, 20, false, new float[]{0.72f, 0.74f, 0.78f});
                for (int k = 0; k < 5; k++) {
                    double ph = k * 2 * Math.PI / 5 + 0.3;
                    float[] pa = polar(0.035f, ph - 0.30, 0.060f), pb = polar(0.188f, ph - 0.12, 0.060f);
                    float[] pc = polar(0.188f, ph + 0.12, 0.060f), pd = polar(0.035f, ph + 0.30, 0.060f);
                    rim.quad(pa, pb, pc, pd, new float[]{0.66f, 0.68f, 0.72f});
                }
                rim.xform(0, B);
                for (Part wp : new Part[]{tire, dish, rim}) {
                    wp.shift(-cx0, -0.29f, -wz);
                    wp.pivot[0] = cx0; wp.pivot[1] = 0.29f; wp.pivot[2] = wz;
                }
                int v3 = well.nv;
                well.revolve(new float[][]{{0.345f, -0.20f, 0, 0}, {0.345f, 0.12f, 0, 0}}, 40, false, BLK);
                well.revolve(new float[][]{{0.345f, -0.20f, 0, 0}, {0.001f, -0.20f, 0, 0}}, 40, false, BLK);
                well.xform(v3, B);
                int nth = 36;
                float[][][] pp = new float[nth + 1][4][3];
                for (int i = 0; i <= nth; i++) {
                    double th = -0.35 + (Math.PI + 0.7) * i / nth;
                    for (int j = 0; j < 4; j++) {
                        float r = 0.305f + 0.028f * j;
                        float z = wz + r * (float) Math.cos(th), y = Math.max(0.23f, 0.29f + r * (float) Math.sin(th));
                        pp[i][j] = f3(sg * (hwAtY(z, y) + 0.004f), y, z);
                    }
                }
                trim.grid(pp, false, null, new float[]{0.02f, 0.02f, 0.022f});
            }
    }

    private static float[] polar(float r, double ph, float u) {
        return f3(r * (float) Math.cos(ph), r * (float) Math.sin(ph), u);
    }

    // ---------- шрифт номера ----------
    private static String[] glyph(char c) {
        switch (c) {
            case '0': return new String[]{"01110","10001","10011","10101","11001","10001","01110"};
            case '1': return new String[]{"00100","01100","00100","00100","00100","00100","01110"};
            case '2': return new String[]{"01110","10001","00001","00010","00100","01000","11111"};
            case '3': return new String[]{"11110","00001","00001","01110","00001","00001","11110"};
            case '4': return new String[]{"00010","00110","01010","10010","11111","00010","00010"};
            case '5': return new String[]{"11111","10000","11110","00001","00001","10001","01110"};
            case '6': return new String[]{"00110","01000","10000","11110","10001","10001","01110"};
            case '7': return new String[]{"11111","00001","00010","00100","01000","01000","01000"};
            case '8': return new String[]{"01110","10001","10001","01110","10001","10001","01110"};
            case '9': return new String[]{"01110","10001","10001","01111","00001","00010","01100"};
            case 'А': return new String[]{"01110","10001","10001","11111","10001","10001","10001"};
            case 'В': return new String[]{"11110","10001","10001","11110","10001","10001","11110"};
            case 'Е': return new String[]{"11111","10000","10000","11110","10000","10000","11111"};
            case 'К': return new String[]{"10001","10010","10100","11000","10100","10010","10001"};
            case 'М': return new String[]{"10001","11011","10101","10101","10001","10001","10001"};
            case 'Н': return new String[]{"10001","10001","10001","11111","10001","10001","10001"};
            case 'О': return new String[]{"01110","10001","10001","10001","10001","10001","01110"};
            case 'Р': return new String[]{"11110","10001","10001","11110","10000","10000","10000"};
            case 'С': return new String[]{"01110","10001","10000","10000","10000","10001","01110"};
            case 'Т': return new String[]{"11111","00100","00100","00100","00100","00100","00100"};
            case 'Х': return new String[]{"10001","10001","01010","00100","01010","10001","10001"};
            case 'У': return new String[]{"10001","10001","01010","00100","00100","00100","00100"};
            default: return new String[]{"00000","00000","00000","00000","00000","00000","00000"};
        }
    }

    private void plate(Part pb, Part pc, float cx, float cy, float z, int nz, String text) {
        float w = 0.26f, h = 0.056f, b = 0.006f;
        pb.rectZ(cx - w, cx + w, cy - h, cy + h, z, nz, PLT, 0f);
        float zz = z + nz * 0.0008f;
        pc.rectZ(cx - w, cx + w, cy + h - b, cy + h, zz, nz, BLK, 0f);
        pc.rectZ(cx - w, cx + w, cy - h, cy - h + b, zz, nz, BLK, 0f);
        pc.rectZ(cx - w, cx - w + b, cy - h, cy + h, zz, nz, BLK, 0f);
        pc.rectZ(cx + w - b, cx + w, cy - h, cy + h, zz, nz, BLK, 0f);
        int dirX = nz;
        float left = cx - dirX * (w - 0.018f);
        float ps = 0.0098f, pitch = 0.060f;
        for (int ci = 0; ci < Math.min(6, text.length()); ci++) {
            String[] g = glyph(text.charAt(ci));
            for (int r = 0; r < 7; r++) for (int c = 0; c < 5; c++)
                if (g[r].charAt(c) == '1') {
                    float xa = left + dirX * (ci * pitch + c * ps), xb = xa + dirX * ps;
                    float yt = cy + 0.035f - r * ps;
                    pc.rectZ(Math.min(xa, xb), Math.max(xa, xb), yt - ps, yt, zz, nz, BLK, 0f);
                }
        }
        float ps2 = 0.0072f, left2 = left + dirX * (6 * pitch + 0.012f);
        for (int ci = 6; ci < Math.min(8, text.length()); ci++) {
            String[] g = glyph(text.charAt(ci));
            for (int r = 0; r < 7; r++) for (int c = 0; c < 5; c++)
                if (g[r].charAt(c) == '1') {
                    float xa = left2 + dirX * ((ci - 6) * 0.044f + c * ps2), xb = xa + dirX * ps2;
                    float yt = cy + 0.040f - r * ps2;
                    pc.rectZ(Math.min(xa, xb), Math.max(xa, xb), yt - ps2, yt, zz, nz, BLK, 0f);
                }
        }
    }

    // ---------- детали: фонари, номера, бамперы ----------
    private void buildDetails() {
        Part trim = twoSided(mk(1, 0.2f, 20f, 0.08f)), chrome = twoSided(mk(1, 1f, 60f, 0.8f));
        Part smoke = twoSided(mk(1, 0.8f, 40f, 0.35f)), brake = twoSided(mk(1, 0.6f, 30f, 0.2f));
        Part amber = twoSided(mk(1, 0.6f, 30f, 0.2f)), white = twoSided(mk(1, 0.6f, 30f, 0.2f));
        Part head = twoSided(mk(1, 0.9f, 60f, 0.5f));
        Part plateP = twoSided(mk(1, 0.4f, 30f, 0.15f)), plateC = twoSided(mk(1, 0.1f, 10f, 0f));
        brake.glowKind = 2; head.glowKind = 3;
        float zr = sp.zRear() - 0.003f, zf = sp.zFront() + 0.003f;

        trim.rectZ(-0.60f, 0.60f, 0.34f, 0.45f, zr - 0.001f, -1, BLK, 0f);
        trim.rectZ(-0.58f, 0.58f, 0.34f, 0.44f, zf + 0.001f, 1, BLK, 0f);

        for (int sg = -1; sg <= 1; sg += 2) {
            float x0 = Math.min(sg * sp.tailX[0], sg * sp.tailX[1]), x1 = Math.max(sg * sp.tailX[0], sg * sp.tailX[1]);
            float inner0 = sg > 0 ? sp.tailX[0] : -sp.tailX[0] - 0.13f, inner1 = inner0 + 0.13f;
            float y0 = sp.tailY[0], y1 = sp.tailY[1];
            trim.rectZ(x0 - 0.008f, x1 + 0.008f, y0 - 0.008f, y1 + 0.008f, zr + 0.0005f, -1, BLK, 0f);
            smoke.rectZ(x0, x1, y0, y1, zr - 0.0005f, -1, REDC, 0f);
            brake.rectZ(inner0, inner1, y0 + 0.02f, y1 - 0.02f, zr - 0.002f, -1, new float[]{0.35f, 0.02f, 0.03f}, 1f);
            float ax0 = sg > 0 ? inner1 + 0.01f : x0, ax1 = sg > 0 ? x1 : inner0 - 0.01f;
            amber.rectZ(ax0, ax1, y1 - 0.05f, y1 - 0.01f, zr - 0.002f, -1, AMB, 0f);
            white.rectZ(ax0, ax1, y0 + 0.01f, y0 + 0.045f, zr - 0.002f, -1, new float[]{0.55f, 0.56f, 0.58f}, 0f);
            // передние фары
            float hx0 = Math.min(sg * sp.headX[0], sg * sp.headX[1]), hx1 = Math.max(sg * sp.headX[0], sg * sp.headX[1]);
            if (sp.roundHeads) {
                float cx = sg * (sp.headX[0] + sp.headX[1]) * 0.5f, cy = (sp.headY[0] + sp.headY[1]) * 0.5f;
                int v0 = head.nv;
                head.revolve(new float[][]{{0.085f, 0f, 0, 0}, {0f, 0.006f, 0, 0}}, 32, false, new float[]{0.55f, 0.57f, 0.6f});
                head.xform(v0, Mat.t(cx, cy, zf + 0.002f));
                int v1 = chrome.nv;
                chrome.revolve(new float[][]{{0.102f, 0f, 0, 0}, {0.102f, 0.010f, 0, 0}, {0.086f, 0.010f, 0, 0}}, 32, false, CHR);
                chrome.xform(v1, Mat.t(cx, cy, zf + 0.001f));
            } else {
                chrome.rectZ(hx0 - 0.008f, hx1 + 0.008f, sp.headY[0] - 0.008f, sp.headY[1] + 0.008f, zf + 0.0005f, 1, CHR, 0f);
                head.rectZ(hx0, hx1, sp.headY[0], sp.headY[1], zf + 0.002f, 1, new float[]{0.55f, 0.57f, 0.6f}, 1f);
            }
        }
        for (int i = 0; i < head.nv; i++) head.gw[i] = 1f;
        // решётка
        chrome.rectZ(-0.285f, 0.285f, 0.545f, 0.675f, zf + 0.0005f, 1, CHR, 0f);
        trim.rectZ(-0.27f, 0.27f, 0.555f, 0.665f, zf + 0.002f, 1, BLK, 0f);
        for (int i = -2; i <= 2; i++) chrome.rectZ(i * 0.10f - 0.004f, i * 0.10f + 0.004f, 0.56f, 0.66f, zf + 0.003f, 1, CHR, 0f);
        plate(plateP, plateC, 0f, 0.485f, zf + 0.0035f, 1, sp.plate);
        plate(plateP, plateC, 0f, 0.53f, zr - 0.0035f, -1, sp.plate);
        // боковые молдинги и швы бамперов
        Part mold = twoSided(mk(1, 0.2f, 20f, 0.08f));
        Part seam = twoSided(mk(1, 0.1f, 10f, 0.02f));
        float[] gray = {0.20f, 0.20f, 0.215f};
        float[] zmold = lin(sp.zRear() + 0.30f, sp.zFront() - 0.30f, 0.08f);
        float[] zseam = {sp.zFront() - 0.44f, sp.zRear() + 0.40f};
        for (int sg = 1; sg >= -1; sg -= 2) {
            float[][][] pm = surf(zmold, new float[]{1.9f, 2.08f}, sg);
            mold.grid(offset(pm, sg > 0, -0.004f), sg > 0, null, gray);
            for (float zz : zseam) {
                float[][][] ps = surf(new float[]{zz - 0.004f, zz + 0.004f}, lin(1.05f, 3.3f, 0.25f), sg);
                seam.grid(offset(ps, sg > 0, -0.003f), sg > 0, null, BLK);
            }
        }
        seam.rectZ(-0.58f, 0.58f, 0.525f, 0.532f, sp.zFront() + 0.002f, 1, BLK, 0f);
        seam.rectZ(-0.60f, 0.60f, 0.47f, 0.477f, sp.zRear() - 0.002f, -1, BLK, 0f);
        // выхлоп
        int ve = chrome.nv;
        chrome.revolve(new float[][]{{0.034f, 0f, 0, 0}, {0.034f, -0.11f, 0, 0}, {0.026f, -0.11f, 0, 0}}, 20, false, CHR);
        chrome.xform(ve, Mat.t(-0.40f, 0.255f, sp.zRear() + 0.01f));
        // неоновая подсветка днища
        Part ug = mk(1, 0.3f, 20f, 0.1f);
        ug.glowKind = 9;
        float zl = sp.zRear() + 0.25f, zr2 = sp.zFront() - 0.25f, zm = (zl + zr2) * 0.5f, hl = (zr2 - zl) * 0.5f;
        ug.box(-0.66f, 0.17f, zm, 0.014f, 0.012f, hl, new float[]{0.1f, 0.1f, 0.1f}, 1f, 1f);
        ug.box(0.66f, 0.17f, zm, 0.014f, 0.012f, hl, new float[]{0.1f, 0.1f, 0.1f}, 1f, 1f);
        ug.box(0f, 0.17f, zl, 0.66f, 0.012f, 0.014f, new float[]{0.1f, 0.1f, 0.1f}, 1f, 1f);
        ug.box(0f, 0.17f, zr2, 0.66f, 0.012f, 0.014f, new float[]{0.1f, 0.1f, 0.1f}, 1f, 1f);
        for (int i = 0; i < ug.nv; i++) ug.gw[i] = 1f;
    }


    // ---------- ночная дорога (бесконечная: детали повторяются с периодом) ----------
    private Part rp(int group, float spec, float shin, float env, float period) {
        Part p = mk(group, spec, shin, env);
        p.road = true; p.period = period;
        return p;
    }

    private void buildRoad() {
        java.util.Random rnd = new java.util.Random(7);
        final float[] WARM = {1f, 0.86f, 0.55f};
        // асфальт, обочины, земля
        roadSurface = rp(0, 0.2f, 14f, 0.12f, 0f);
        roadSurface.twoSided = true;
        Part shoulder = rp(0, 0.05f, 10f, 0.02f, 0f), land = rp(0, 0.02f, 8f, 0f, 0f);
        shoulder.twoSided = true; land.twoSided = true; shoulder.glowKind = 11;
        float[] zr = new float[75];
        for (int i = 0; i < zr.length; i++) zr[i] = i <= 40 ? -40f + i * 1.5f : 20f + (i - 40) * 8.5f;
        float[][][] pr = new float[zr.length][7][];
        float[] xr = {-5.2f, -3.5f, -1.8f, 0f, 1.8f, 3.5f, 5.2f};
        for (int i = 0; i < zr.length; i++) for (int j = 0; j < 7; j++) pr[i][j] = f3(xr[j], 0f, zr[i]);
        roadSurface.grid(pr, false, null, new float[]{0.050f, 0.052f, 0.058f});
        for (int sg = -1; sg <= 1; sg += 2) {
            float[][][] ps = new float[zr.length][2][], pl = new float[zr.length][2][];
            for (int i = 0; i < zr.length; i++) {
                ps[i][0] = f3(sg * 5.2f, 0f, zr[i]); ps[i][1] = f3(sg * 13f, 0f, zr[i]);
                pl[i][0] = f3(sg * 13f, 0f, zr[i]); pl[i][1] = f3(sg * 90f, 0f, zr[i]);
            }
            float[][] gw = new float[zr.length][2];
            for (float[] r : gw) { r[0] = 1f; r[1] = 1f; }
            shoulder.grid(ps, false, false, null, new float[]{0.055f, 0.057f, 0.06f}, gw, null);
            land.grid(pl, false, null, new float[]{0.018f, 0.026f, 0.022f});
        }
        // боковые линии
        Part edge = rp(0, 0.1f, 10f, 0.05f, 0f);
        edge.glowKind = 12; edge.glowCol = new float[]{1f, 0.95f, 0.85f}; edge.glowAmt = 0.22f;
        for (int sg = -1; sg <= 1; sg += 2) {
            float[][][] pe = new float[zr.length][2][];
            for (int i = 0; i < zr.length; i++) { pe[i][0] = f3(sg * 4.85f, 0.004f, zr[i]); pe[i][1] = f3(sg * 5.0f, 0.004f, zr[i]); }
            float[][] g1 = new float[zr.length][2];
            for (float[] r : g1) { r[0] = 1f; r[1] = 1f; }
            edge.grid(pe, false, false, null, new float[]{0.75f, 0.75f, 0.7f}, g1, null);
        }
        // разметка (пунктир)
        Part dash = rp(7, 0.1f, 10f, 0.05f, 12f);
        dash.glowKind = 12; dash.glowCol = new float[]{1f, 0.95f, 0.85f}; dash.glowAmt = 0.22f;
        for (int k = -4; k < 30; k++) {
            float z0 = k * 12f;
            dash.quad(f3(-0.09f, 0.005f, z0), f3(0.09f, 0.005f, z0), f3(0.09f, 0.005f, z0 + 4f), f3(-0.09f, 0.005f, z0 + 4f), new float[]{0.75f, 0.75f, 0.68f}, 1f);
        }
        // столбики-катафоты
        Part post = rp(7, 0.4f, 20f, 0.1f, 14f);
        post.glowKind = 12; post.glowCol = new float[]{1f, 0.95f, 0.85f}; post.glowAmt = 0.35f;
        for (int k = -4; k < 28; k++) for (int sg = -1; sg <= 1; sg += 2)
            post.box(sg * 5.5f, 0.45f, k * 14f, 0.035f, 0.45f, 0.035f, new float[]{0.8f, 0.8f, 0.78f}, 1f, 1f);
        for (int i = 0; i < post.nv; i++) post.gw[i] = 1f;
        // фонари (по 2 на период 56 м, поочерёдно слева/справа)
        Part pole = rp(7, 0.4f, 20f, 0.1f, 56f), head = rp(7, 0.5f, 20f, 0.1f, 56f), pool = rp(7, 0f, 1f, 0f, 56f);
        head.glowKind = 12; head.glowCol = WARM.clone(); head.glowAmt = 1.6f;
        pool.additive = true; pool.twoSided = true; pool.alpha = 0.5f; pool.glowCol = new float[]{1f, 0.82f, 0.5f}; pool.glowAmt = 0.30f;
        for (int m = -1; m < 7; m++) for (int side = 0; side < 2; side++) {
            float sgn = side == 0 ? 1f : -1f, z = m * 56f + side * 28f;
            pole.box(sgn * 6.4f, 3.4f, z, 0.07f, 3.4f, 0.07f, new float[]{0.06f, 0.06f, 0.065f}, 0f, 0f);
            pole.box(sgn * 5.5f, 6.75f, z, 0.9f, 0.04f, 0.04f, new float[]{0.06f, 0.06f, 0.065f}, 0f, 0f);
            head.box(sgn * 4.7f, 6.68f, z, 0.30f, 0.05f, 0.13f, new float[]{0.9f, 0.8f, 0.55f}, 1f, 1f);
            int segs = 20, rings = 6;
            float[][][] pp = new float[segs + 1][rings][3];
            float[][] gg = new float[segs + 1][rings];
            for (int i = 0; i <= segs; i++) {
                double a = 2 * Math.PI * i / segs;
                for (int j = 0; j < rings; j++) {
                    float r = (float) j / (rings - 1);
                    pp[i][j] = f3(sgn * 3.8f + 5.2f * r * (float) Math.cos(a), 0.016f, z + 5.2f * r * (float) Math.sin(a));
                    gg[i][j] = (float) Math.pow(1f - r, 1.6);
                }
            }
            pool.grid(pp, true, false, null, new float[]{0f, 0f, 0f}, gg, null);
        }
        for (int i = 0; i < head.nv; i++) head.gw[i] = 1f;
        // дома вдали
        Part bld = rp(7, 0.05f, 10f, 0.02f, 120f), win = rp(7, 0.1f, 10f, 0.02f, 120f);
        win.glowKind = 12; win.glowCol = new float[]{1f, 0.9f, 0.7f}; win.glowAmt = 1.0f;
        for (int m = -1; m < 4; m++) for (int side = 0; side < 2; side++) {
            float sgn = side == 0 ? 1f : -1f;
            for (int b = 0; b < 6; b++) {
                float z = m * 120f + b * 20f + rnd.nextFloat() * 4f;
                float depth = 12f + rnd.nextFloat() * 6f, hgt = 9f + rnd.nextFloat() * 20f, len = 12f + rnd.nextFloat() * 5f;
                float x = sgn * (20f + rnd.nextFloat() * 10f + depth * 0.5f);
                bld.box(x, hgt * 0.5f, z, depth * 0.5f, hgt * 0.5f, len * 0.5f, new float[]{0.035f, 0.04f, 0.05f}, 0f, 0f);
                float fx = x - sgn * depth * 0.5f - sgn * 0.02f;
                for (float wy = 2.2f; wy < hgt - 1.2f; wy += 2.6f)
                    for (float wz = z - len * 0.5f + 1.4f; wz < z + len * 0.5f - 1.0f; wz += 2.6f) {
                        if (rnd.nextFloat() > 0.38f) continue;
                        float[] wc = rnd.nextFloat() < 0.7f ? new float[]{1f, 0.85f, 0.55f} : new float[]{0.6f, 0.8f, 1f};
                        if (sgn > 0) win.quad(f3(fx, wy, wz), f3(fx, wy, wz + 1.0f), f3(fx, wy + 1.3f, wz + 1.0f), f3(fx, wy + 1.3f, wz), wc, 1f);
                        else win.quad(f3(fx, wy, wz + 1.0f), f3(fx, wy, wz), f3(fx, wy + 1.3f, wz), f3(fx, wy + 1.3f, wz + 1.0f), wc, 1f);
                    }
            }
        }
        for (int i = 0; i < win.nv; i++) win.gw[i] = 1f;
        // луна и звёзды
        Part moon = rp(0, 0f, 1f, 0f, 0f);
        moon.twoSided = true; moon.glowKind = 12; moon.glowCol = new float[]{0.95f, 0.97f, 1f}; moon.glowAmt = 1.4f;
        int vm = moon.nv;
        moon.revolve(new float[][]{{9f, 0f, 0, 1f}, {0.001f, 0f, 0, 1f}}, 28, false, new float[]{0.6f, 0.62f, 0.66f});
        moon.xform(vm, Mat.t(-80f, 85f, 300f));
        for (int i = 0; i < moon.nv; i++) moon.gw[i] = 1f;
        Part stars = rp(0, 0f, 1f, 0f, 0f);
        stars.twoSided = true; stars.glowKind = 12; stars.glowCol = new float[]{0.9f, 0.93f, 1f}; stars.glowAmt = 0.9f;
        for (int i = 0; i < 90; i++) {
            float sx0 = (rnd.nextFloat() - 0.5f) * 520f, sy0 = 30f + rnd.nextFloat() * 130f, sz0 = 320f;
            float sz = 0.4f + rnd.nextFloat() * 0.5f;
            stars.quad(f3(sx0 - sz, sy0 - sz, sz0), f3(sx0 + sz, sy0 - sz, sz0), f3(sx0 + sz, sy0 + sz, sz0), f3(sx0 - sz, sy0 + sz, sz0), new float[]{0.7f, 0.75f, 0.9f}, 1f);
        }
        for (int i = 0; i < stars.nv; i++) stars.gw[i] = 1f;
    }

    // ---------- мир: пол, лучи фар, волны, эквалайзер ----------
    private void buildBeams() {
        float zFront = heads[0][2];
        for (int sd = 0; sd < 2; sd++) {
            float[] h = heads[sd];
            float[] rsl = {1.0f, 0.84f, 0.68f, 0.54f, 0.42f, 0.30f, 0.19f};
            for (int layer = 0; layer < rsl.length; layer++) {
                Part cone = mk(1, 0f, 1f, 0f);
                cone.additive = true; cone.twoSided = true; cone.glowKind = 8; cone.alpha = 0.5f;
                float rs = rsl[layer];
                float wt = 0.034f;
                int seg = 20, rows = 11;
                float L = 11f;
                float[][][] p = new float[seg + 1][rows][3];
                float[][] gw = new float[seg + 1][rows];
                for (int j = 0; j < rows; j++) {
                    float t = (float) j / (rows - 1);
                    float d = 0.1f + L * (float) Math.pow(t, 1.25);
                    float rad = (0.05f + 0.21f * d) * rs;
                    float cy = h[1] - 0.035f * d, cz = h[2] + d;
                    for (int i = 0; i <= seg; i++) {
                        double a = 2 * Math.PI * i / seg;
                        p[i][j] = f3(h[0] + rad * (float) Math.cos(a) * (sd == 0 ? 1.0f : 1.0f), cy + rad * 0.7f * (float) Math.sin(a), cz);
                        gw[i][j] = wt * (float) Math.pow(1f - t, 2.0);
                    }
                }
                cone.grid(p, true, false, null, new float[]{0f, 0f, 0f}, gw, null);
            }
            // световое пятно на асфальте, начинается заметно впереди бампера
            Part pool = mk(0, 0f, 1f, 0f);
            pool.additive = true; pool.twoSided = true; pool.glowKind = 8; pool.alpha = 0.5f;
            int seg = 28, rings = 7;
            float[][][] pp = new float[seg + 1][rings][3];
            float[][] pg = new float[seg + 1][rings];
            float cx = h[0] * 1.15f, zc = zFront + 6.8f;
            for (int i = 0; i <= seg; i++) {
                double a = 2 * Math.PI * i / seg;
                for (int j = 0; j < rings; j++) {
                    float r = (float) j / (rings - 1);
                    pp[i][j] = f3(cx + 1.7f * r * (float) Math.cos(a), 0.012f, zc + 5.2f * r * (float) Math.sin(a));
                    pg[i][j] = 0.50f * (float) Math.pow(1f - r, 2.0);
                }
            }
            pool.grid(pp, true, false, null, new float[]{0f, 0f, 0f}, pg, null);
            poolParts.add(pool);
        }
    }

    private void buildWorld() {
        groundPart = mk(0, 0.25f, 14f, 0.10f);
        groundPart.glowKind = 5;
        float[] rr = {0.001f, 0.6f, 1.4f, 2.4f, 3.6f, 5f, 7f, 9.5f, 13f};
        int seg = 56;
        float[][][] p = new float[seg + 1][rr.length][3];
        float[][] gw = new float[seg + 1][rr.length];
        for (int i = 0; i <= seg; i++) {
            double a = 2 * Math.PI * i / seg;
            for (int j = 0; j < rr.length; j++) {
                p[i][j] = f3(rr[j] * (float) Math.cos(a), 0f, rr[j] * (float) Math.sin(a));
                gw[i][j] = (float) Math.exp(-Math.pow(rr[j] / 3.4, 2));
            }
        }
        groundPart.grid(p, true, false, null, ASPH, gw, null);

        Part shadow = mk(0, 0.25f, 14f, 0.10f);
        shadowPart = shadow;
        shadow.glowKind = 5;
        {
            int sgN = 40;
            float[] rrs = {0.001f, 0.30f, 0.55f, 0.78f, 1.0f};
            float[][][] sp2 = new float[sgN + 1][rrs.length][3];
            for (int i = 0; i <= sgN; i++) {
                double a = 2 * Math.PI * i / sgN;
                for (int j = 0; j < rrs.length; j++)
                    sp2[i][j] = f3(1.15f * rrs[j] * (float) Math.cos(a), 0.004f, 2.55f * rrs[j] * (float) Math.sin(a));
            }
            shadow.grid(sp2, true, false, null, ASPH, null, null);
            for (int i = 0; i < shadow.nv; i++) {
                float x = shadow.pos[i * 3] / 1.15f, z = shadow.pos[i * 3 + 2] / 2.55f;
                float r = (float) Math.sqrt(x * x + z * z);
                float w = Math.max(0f, 1f - r);
                float k = 1f - 0.92f * (float) Math.pow(w, 0.8);
                shadow.col[i * 3] = ASPH[0] * k; shadow.col[i * 3 + 1] = ASPH[1] * k; shadow.col[i * 3 + 2] = ASPH[2] * k;
                float gr = (float) Math.hypot(shadow.pos[i * 3], shadow.pos[i * 3 + 2]);
                shadow.gw[i] = (float) Math.exp(-Math.pow(gr / 3.4, 2)) * k;
            }
        }

        beamPart = null;
        poolParts.clear();
        if (modelIdx != OBJ_MODEL) {
            float hx = (sp.headX[0] + sp.headX[1]) * 0.5f, hy = (sp.headY[0] + sp.headY[1]) * 0.5f;
            heads[0] = f3(-hx, hy, sp.zFront() + 0.02f); heads[1] = f3(hx, hy, sp.zFront() + 0.02f);
            float tx = (sp.tailX[0] + sp.tailX[1]) * 0.5f, ty = (sp.tailY[0] + sp.tailY[1]) * 0.5f;
            tails[0] = f3(-tx, ty, sp.zRear() - 0.02f); tails[1] = f3(tx, ty, sp.zRear() - 0.02f);
        }
        buildBeams();

        for (int i = 0; i < ringParts.length; i++) {
            Part r = mk(3, 0.05f, 10f, 0f);
            r.glowKind = 4;
            r.group = 3;
            float[][][] q = new float[73][2][3];
            for (int k = 0; k <= 72; k++) {
                double a = 2 * Math.PI * k / 72;
                q[k][0] = f3(0.93f * (float) Math.cos(a), 0f, 0.93f * (float) Math.sin(a));
                q[k][1] = f3((float) Math.cos(a), 0f, (float) Math.sin(a));
            }
            float[][] g2 = new float[73][2];
            for (float[] row : g2) { row[0] = 0.5f; row[1] = 1f; }
            r.grid(q, true, false, null, new float[]{0f, 0f, 0f}, g2, null);
            r.twoSided = true;
            ringParts[i] = r;
        }
        for (int i = 0; i < BANDS; i++) {
            Part b = mk(4, 0.2f, 20f, 0.05f);
            b.group = 4;
            b.glowKind = 6;
            b.box(0f, 0.5f, 0f, 0.17f, 0.5f, 0.17f, new float[]{0.03f, 0.03f, 0.035f}, 0.15f, 1f);
            barParts[i] = b;
        }
    }


    // ================= BMW E30 из файла (OBJ) =================
    private boolean isWheelMat(String m) {
        return m.startsWith("TARMAC") || m.equals("DISCS") || m.equals("CALIPER") || m.equals("SUSPENSION");
    }

    private void buildObj() {
        parts.clear();
        Arrays.fill(ringParts, null);
        Arrays.fill(barParts, null);
        ObjCar oc = ObjCar.get(assets);
        final float K = 1.72f, DY = 0.437177f * K;
        final float DZ0 = -0.30f, DZ1 = 0.33f, DY0 = -0.215f, DY1 = 0.40f, DX = 0.30f;
        final float LZ1 = -0.74f, LY0 = 0.055f;
        int nt = oc.nt;
        int[] pid = new int[nt];
        for (int f = 0; f < nt; f++) {
            int a = oc.idx[f * 3], b = oc.idx[f * 3 + 1], c = oc.idx[f * 3 + 2];
            float cx = (oc.pos[a*3] + oc.pos[b*3] + oc.pos[c*3]) / 3f, cy = (oc.pos[a*3+1] + oc.pos[b*3+1] + oc.pos[c*3+1]) / 3f,
                  cz = (oc.pos[a*3+2] + oc.pos[b*3+2] + oc.pos[c*3+2]) / 3f;
            String m = oc.mats[oc.tmat[f]];
            int cls = oc.tcls[f];
            int id = 1;
            boolean doorMat = m.equals("CAR_BODY_PAINT") || m.equals("MATT") || m.equals("SHINY_METAL") || m.equals("WINDOW_GLASS") || m.equals("CABIN");
            boolean lidMat = m.equals("CAR_BODY_PAINT") || m.equals("MATT") || m.equals("SHINY_METAL");
            float minX = 9, maxX = -9, minY = 9, maxY = -9, minZ = 9, maxZ = -9;
            for (int k3 = 0; k3 < 3; k3++) {
                int v = oc.idx[f * 3 + k3];
                float vx = Math.abs(oc.pos[v*3]), vy = oc.pos[v*3+1], vz = oc.pos[v*3+2];
                minX = Math.min(minX, vx); maxX = Math.max(maxX, vx);
                minY = Math.min(minY, vy); maxY = Math.max(maxY, vy);
                minZ = Math.min(minZ, vz); maxZ = Math.max(maxZ, vz);
            }
            boolean doorBox = Math.abs(cx) > DX && cz > DZ0 && cz < DZ1 && cy > DY0 && cy < DY1
                    && minX > 0.2f && minZ > DZ0 - 0.06f && maxZ < DZ1 + 0.06f && minY > DY0 - 0.1f && maxY < DY1 + 0.1f;
            boolean lidBox = lidMat && cls == 0 && cz < LZ1 && cy > LY0 && maxX < 0.43f && maxZ < LZ1 + 0.03f && minY > LY0 - 0.04f;
            if (m.startsWith("TARMAC")) id = 10 + (cx > 0 ? 1 : 0) + (cz > 0 ? 2 : 0);
            else if (isWheelMat(m)) id = 0;
            else if (cls == 1) id = 2;
            else if (cls == 2 || lidBox) id = 3;
            else if (cls == 3) id = cx > 0 ? 4 : 5;
            else if (doorMat && doorBox) id = cx > 0 ? 4 : 5;
            else if (m.startsWith("LIGHTS")) id = cz > 0 ? 6 : 7;
            else if (m.equals("CABIN")) id = 8;
            pid[f] = id;
            pid[f] = id;
        }
        // опорные точки шарниров (в мировых координатах)
        float hoodZ = 1e9f, trunkZ = -1e9f;
        for (int f = 0; f < nt; f++) for (int c = 0; c < 3; c++) {
            int v = oc.idx[f * 3 + c];
            if (pid[f] == 2) hoodZ = Math.min(hoodZ, oc.pos[v*3+2]);
            if (pid[f] == 3) trunkZ = Math.max(trunkZ, oc.pos[v*3+2]);
        }
        float hoodY = 0f, trunkY = 0f; int hn = 0, tn = 0;
        for (int f = 0; f < nt; f++) for (int c = 0; c < 3; c++) {
            int v = oc.idx[f * 3 + c];
            if (pid[f] == 2 && oc.pos[v*3+2] < hoodZ + 0.03f) { hoodY += oc.pos[v*3+1]; hn++; }
            if (pid[f] == 3 && oc.pos[v*3+2] > trunkZ - 0.03f) { trunkY += oc.pos[v*3+1]; tn++; }
        }
        float[][] wmin = new float[4][3], wmax = new float[4][3];
        for (int q = 0; q < 4; q++) { Arrays.fill(wmin[q], 1e9f); Arrays.fill(wmax[q], -1e9f); }
        for (int f = 0; f < nt; f++) {
            if (pid[f] < 10) continue;
            int q = pid[f] - 10;
            for (int c = 0; c < 3; c++) {
                int v = oc.idx[f * 3 + c];
                for (int k2 = 0; k2 < 3; k2++) {
                    wmin[q][k2] = Math.min(wmin[q][k2], oc.pos[v*3+k2]);
                    wmax[q][k2] = Math.max(wmax[q][k2], oc.pos[v*3+k2]);
                }
            }
        }
        float[][] wheelPivot = new float[4][];
        for (int q = 0; q < 4; q++)
            wheelPivot[q] = f3((wmin[q][0] + wmax[q][0]) * 0.5f * K, (wmin[q][1] + wmax[q][1]) * 0.5f * K + DY, (wmin[q][2] + wmax[q][2]) * 0.5f * K);
        float[] hoodPivot = {0f, (hn > 0 ? hoodY / hn : 0.05f) * K + DY, hoodZ * K};
        float[] trunkPivot = {0f, (tn > 0 ? trunkY / tn : 0.15f) * K + DY, trunkZ * K};

        java.util.HashMap<Integer, Part> map = new java.util.HashMap<>();
        java.util.HashMap<Part, int[]> remaps = new java.util.HashMap<>();
        for (int f = 0; f < nt; f++) {
            int mi = oc.tmat[f], id = pid[f];
            int key = id * 64 + mi;
            Part p = map.get(key);
            if (p == null) {
                String m = oc.mats[mi];
                int group = id == 0 ? 0 : (id >= 2 && id <= 5) ? 2 : id >= 10 ? 6 : 1;
                p = mk(group, 0.15f, 20f, 0.05f);
                p.tex = oc.tex[oc.texIndex(m)];
                p.uv = new float[64];
                p.pos = new float[96]; p.nrm = new float[96];
                if (m.equals("CAR_BODY_PAINT")) { p.tintPaint = true; p.spec = 0.9f; p.shin = 60f; p.env = 0.5f; p.twoSided = true; }
                else if (m.equals("SHINY_METAL")) { p.spec = 1f; p.shin = 60f; p.env = 0.8f; }
                else if (m.equals("LIGHTS_GLASS")) { p.alpha = 0.6f; p.spec = 1f; p.shin = 60f; p.env = 0.6f; }
                else if (m.equals("WINDOW_GLASS")) { p.alpha = 0.4f; p.spec = 1f; p.shin = 80f; p.env = 0.9f; p.twoSided = true; }
                else if (m.equals("TARMAC_WHEEL") || m.equals("DISCS")) { p.spec = 0.8f; p.shin = 50f; p.env = 0.5f; }
                else if (m.startsWith("LIGHTS")) { p.spec = 0.6f; p.shin = 40f; p.env = 0.3f; }
                else if (m.equals("MATT") && (id == 4 || id == 5)) p.twoSided = true;
                if (id == 6 && m.startsWith("LIGHTS")) p.glowKind = 3;
                if (id == 7 && m.startsWith("LIGHTS")) p.glowKind = 2;
                if (id == 8 || (m.equals("CABIN"))) p.glowKind = 7;
                if (id >= 10) p.pivot = wheelPivot[id - 10].clone();
                if (id >= 2 && id <= 5) {
                    p.axis = id >= 4 ? 1 : 2;
                    p.ctrl = id == 2 ? 3 : id == 3 ? 2 : 1;
                    if (id == 2) { p.pivot = hoodPivot.clone(); p.maxAng = 56f * (float) Math.PI / 180f; p.dir = -1f; }
                    else if (id == 3) { p.pivot = trunkPivot.clone(); p.maxAng = 62f * (float) Math.PI / 180f; p.dir = 1f; }
                    else {
                        int sg = id == 4 ? 1 : -1;
                        p.pivot = new float[]{sg * 0.47f * K, 0f, DZ1 * K};
                        p.maxAng = 62f * (float) Math.PI / 180f; p.dir = -sg;
                    }
                }
                map.put(key, p);
                int[] rmi = new int[oc.nv];
                Arrays.fill(rmi, -1);
                remaps.put(p, rmi);
            }
            int[] rm = remaps.get(p);
            for (int c = 0; c < 3; c++) {
                int v = oc.idx[f * 3 + c];
                float x = oc.pos[v*3] * K, y = oc.pos[v*3+1] * K + DY, z = oc.pos[v*3+2] * K;
                if (p.group == 2 || p.group == 6) { x -= p.pivot[0]; y -= p.pivot[1]; z -= p.pivot[2]; }
                int nvI = rm[v];
                if (nvI < 0) {
                    nvI = p.addRaw(x, y, z, oc.nrm[v*3], oc.nrm[v*3+1], oc.nrm[v*3+2], oc.uv[v*2], oc.uv[v*2+1]);
                    rm[v] = nvI;
                }
                p.tri(nvI);
            }
        }
        for (Part p : parts) {
            if (p.glowKind == 3 || p.glowKind == 2) for (int i = 0; i < p.nv; i++) p.gw[i] = 1f;
            if (p.glowKind == 7) p.glowByPoint(0f, 1.15f, 0f, 2.0f, 0.18f);
        }
        {
            float[] hs = new float[6], ts = new float[6]; int[] hn2 = new int[2], tn2 = new int[2];
            for (int f = 0; f < nt; f++) {
                if (pid[f] != 6 && pid[f] != 7) continue;
                int a = oc.idx[f * 3], b = oc.idx[f * 3 + 1], c2 = oc.idx[f * 3 + 2];
                float cx = (oc.pos[a*3] + oc.pos[b*3] + oc.pos[c2*3]) / 3f * K, cy = (oc.pos[a*3+1] + oc.pos[b*3+1] + oc.pos[c2*3+1]) / 3f * K + DY,
                      cz = (oc.pos[a*3+2] + oc.pos[b*3+2] + oc.pos[c2*3+2]) / 3f * K;
                int sd = cx > 0 ? 1 : 0;
                if (pid[f] == 6) { hs[sd*3] += cx; hs[sd*3+1] += cy; hs[sd*3+2] = Math.max(hs[sd*3+2] == 0 ? -9 : hs[sd*3+2], cz); hn2[sd]++; }
                else { ts[sd*3] += cx; ts[sd*3+1] += cy; ts[sd*3+2] = Math.min(ts[sd*3+2] == 0 ? 9 : ts[sd*3+2], cz); tn2[sd]++; }
            }
            for (int sd = 0; sd < 2; sd++) {
                if (hn2[sd] > 0) heads[sd] = f3(hs[sd*3] / hn2[sd], hs[sd*3+1] / hn2[sd], hs[sd*3+2] + 0.02f);
                else heads[sd] = f3(sd == 0 ? -0.62f : 0.62f, 0.75f, 2.15f);
                if (tn2[sd] > 0) tails[sd] = f3(ts[sd*3] / tn2[sd], ts[sd*3+1] / tn2[sd], ts[sd*3+2] - 0.02f);
                else tails[sd] = f3(sd == 0 ? -0.6f : 0.6f, 0.95f, -2.15f);
            }
        }
        buildSubAssembly(0f, 0.80f, -1.66f, 72f, 0.44f, 0.31f, 0.58f, 0.25f);
        eyeLocal = new float[]{0.36f, 1.13f, 0.06f};
        buildWorld();
        buildRoad();
        arr = parts.toArray(new Part[0]);
    }

    // ================= рендер =================
    private int[] fb = new int[0];
    private float[] zb = new float[0];
    private float[] sx = new float[0], sy = new float[0], iz = new float[0], cr = new float[0], cg = new float[0], cb = new float[0];
    private int fbW, fbH;
    private float ex, ey, ez, rx, ry, rz, ux, uy, uz, fx, fy, fz, foc;
    private float l1x, l1y, l1z, l2x, l2y, l2z;

    private static float norm3(float[] v) {
        float l = (float) Math.sqrt(v[0]*v[0] + v[1]*v[1] + v[2]*v[2]);
        v[0] /= l; v[1] /= l; v[2] /= l;
        return l;
    }

    private static float p16(float x) { x *= x; x *= x; x *= x; return x * x; }
    private static float pSq(float x, int n) { for (int i = 0; i < n; i++) x *= x; return x; }

    public void render(int[] out, int w, int h, int ss, boolean transparent) {
        int W = w * ss, H = h * ss;
        if (fb.length != W * H) { fb = new int[W * H]; zb = new float[W * H]; }
        fbW = W; fbH = H;
        updateDynamics();
        Arrays.fill(zb, 0f);
        if (transparent) Arrays.fill(fb, 0);
        else {
            for (int y = 0; y < H; y++) {
                float t = (float) y / H;
                int r = (int) (8 + 14 * t), g = (int) (10 + 18 * t), b = (int) (17 + 28 * t);
                Arrays.fill(fb, y * W, (y + 1) * W, 0xFF000000 | (r << 16) | (g << 8) | b);
            }
        }
        float[] f;
        float fv = fov;
        boolean roadView = viewMode != 0;
        fogOn = roadView;
        if (viewMode == 2) {
            float[] M = mbody;
            ex = M[0]*eyeLocal[0] + M[1]*eyeLocal[1] + M[2]*eyeLocal[2] + M[3];
            ey = M[4]*eyeLocal[0] + M[5]*eyeLocal[1] + M[6]*eyeLocal[2] + M[7];
            ez = M[8]*eyeLocal[0] + M[9]*eyeLocal[1] + M[10]*eyeLocal[2] + M[11];
            float cpl = (float) Math.cos(lookPitch), spl = (float) Math.sin(lookPitch);
            f = new float[]{-(float) Math.sin(lookYaw) * cpl, spl, (float) Math.cos(lookYaw) * cpl};
            fv = 0.88f;
            nearZ = 0.07f;
        } else {
            float cp = (float) Math.cos(pitch), spn = (float) Math.sin(pitch), cyw = (float) Math.cos(yaw), syw = (float) Math.sin(yaw);
            float tx = 0f, ty = 0.78f, tz = 0f;
            ex = tx + dist * cp * syw; ey = ty + dist * spn; ez = tz + dist * cp * cyw;
            f = new float[]{tx - ex, ty - ey, tz - ez};
            nearZ = 0.3f;
        }
        norm3(f);
        fx = f[0]; fy = f[1]; fz = f[2];
        float[] r = {fy * 0f - fz * 1f, fz * 0f - fx * 0f, fx * 1f - fy * 0f};   // forward x up
        norm3(r);
        rx = r[0]; ry = r[1]; rz = r[2];
        ux = ry * fz - rz * fy; uy = rz * fx - rx * fz; uz = rx * fy - ry * fx;
        foc = 0.5f * Math.min(W, H) / (float) Math.tan(fv);
        float[] a = {-0.55f * rx + 0.75f * ux - 0.50f * fx, -0.55f * ry + 0.75f * uy - 0.50f * fy, -0.55f * rz + 0.75f * uz - 0.50f * fz};
        norm3(a); l1x = a[0]; l1y = a[1]; l1z = a[2];
        float[] b = {0.80f * rx + 0.15f * ux - 0.40f * fx, 0.80f * ry + 0.15f * uy - 0.40f * fy, 0.80f * rz + 0.15f * uz - 0.40f * fz};
        norm3(b); l2x = b[0]; l2y = b[1]; l2z = b[2];

        for (Part p : arr) {
            if (p.alpha < 1f) continue;
            if (p.road && !roadView) continue;
            if ((p == groundPart || p == shadowPart) && (!showGround || roadView)) continue;
            drawPart(p, false);
        }
        for (Part p : arr) {
            if (p.alpha >= 1f) continue;
            if (p.road && !roadView) continue;
            if (p.additive && p.glowKind == 8) {
                if (headA < 0.02f) continue;
                if (poolParts.contains(p) && !showGround && !roadView) continue;
            }
            drawPart(p, true);
        }
        if (headA > 0.02f) {
            for (float[] hp : heads) glare(hp, 1f, 1f, 0.93f, 0.78f, 0.55f, headA);
            for (float[] tp : tails) glare(tp, -1f, 1f, 0.10f, 0.05f, 0.30f, 0.35f * headA);
        }
        if (roadView) {
            long n0 = (long) Math.floor(odo / 28f);
            for (int k = 0; k < 11; k++) {
                long g = n0 + k;
                float zz = g * 28f - odo;
                float sd = (g % 2 == 0) ? 1f : -1f;
                glareW(sd * 4.7f, 6.68f, zz, 1.1f, 0f, 1f, 0.84f, 0.52f, 0.85f);
            }
        }
        if (!transparent && (rain || snow)) weather();
        // понижение разрешения
        int n = ss * ss;
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++) {
                if (ss == 1) { out[y * w + x] = fb[y * W + x]; continue; }
                int sa = 0, sr = 0, sg = 0, sb = 0;
                for (int yy = 0; yy < ss; yy++) {
                    int o = (y * ss + yy) * W + x * ss;
                    for (int xx = 0; xx < ss; xx++) {
                        int c = fb[o + xx];
                        int al = c >>> 24;
                        sa += al; sr += ((c >> 16) & 255) * al; sg += ((c >> 8) & 255) * al; sb += (c & 255) * al;
                    }
                }
                if (sa == 0) out[y * w + x] = 0;
                else out[y * w + x] = ((sa / n) << 24) | ((sr / sa) << 16) | ((sg / sa) << 8) | (sb / sa);
            }
        if (ss == 1 && !transparent) fxaa(out, w, h);
    }

    private boolean curAdd, fogOn;
    private float nearZ = 0.3f;
    private float[] ar = new float[0], ag = new float[0], ab = new float[0], tu = new float[0], tv = new float[0];

    private void drawPart(Part p, boolean blend) {
        int nv = p.nv;
        if (sx.length < nv) {
            int m = nv + 256;
            sx = new float[m]; sy = new float[m]; iz = new float[m]; cr = new float[m]; cg = new float[m]; cb = new float[m];
            ar = new float[m]; ag = new float[m]; ab = new float[m]; tu = new float[m]; tv = new float[m];
        }
        float[] M = p.m;
        float[] pc = PAINT[paintIdx];
        boolean paint = p.paint;
        boolean textured = p.tex != null;
        float spec = paint ? pc[4] : p.spec, env = paint ? pc[3] : p.env;
        if (p.tintPaint) { spec = pc[4] * p.spec; env = pc[3]; }
        int sq = p.shin >= 55f ? 6 : p.shin >= 28f ? 5 : p.shin >= 14f ? 4 : 3;
        float gR = p.glowCol[0] * p.glowAmt, gG = p.glowCol[1] * p.glowAmt, gB = p.glowCol[2] * p.glowAmt;
        float dk = subExc * 0.05f;
        boolean aoOn = p.group != 3 && p.group != 4 && p != groundPart && p != beamPart && p != shadowPart;
        float tintR = 1f, tintG = 1f, tintB = 1f;
        curAdd = p.additive;
        if (p.tintPaint) { tintR = Math.min(1.3f, pc[0] / 0.9f); tintG = Math.min(1.3f, pc[1] / 0.9f); tintB = Math.min(1.3f, pc[2] / 0.9f); }
        float hx2 = fbW * 0.5f, hy2 = fbH * 0.5f;
        for (int v = 0; v < nv; v++) {
            float lx = p.pos[v*3], ly = p.pos[v*3+1], lz = p.pos[v*3+2];
            if (p.deform == 1) lz += p.dw[v] * dk;
            float wx = M[0]*lx + M[1]*ly + M[2]*lz + M[3];
            float wy = M[4]*lx + M[5]*ly + M[6]*lz + M[7];
            float wz = M[8]*lx + M[9]*ly + M[10]*lz + M[11];
            float dx = wx - ex, dy = wy - ey, dz = wz - ez;
            float cz = dx*fx + dy*fy + dz*fz;
            if (cz < nearZ) { iz[v] = -1f; continue; }
            float cxv = dx*rx + dy*ry + dz*rz, cyv = dx*ux + dy*uy + dz*uz;
            sx[v] = hx2 + foc * cxv / cz;
            sy[v] = hy2 - foc * cyv / cz;
            float izv = 1f / cz;
            iz[v] = izv;
            if (textured) { tu[v] = p.uv[v*2] * izv; tv[v] = p.uv[v*2+1] * izv; }
            if (curAdd) { float gwv = p.gw[v]; cr[v] = gR * gwv; cg[v] = gG * gwv; cb[v] = gB * gwv; continue; }

            float nx = M[0]*p.nrm[v*3] + M[1]*p.nrm[v*3+1] + M[2]*p.nrm[v*3+2];
            float ny = M[4]*p.nrm[v*3] + M[5]*p.nrm[v*3+1] + M[6]*p.nrm[v*3+2];
            float nz = M[8]*p.nrm[v*3] + M[9]*p.nrm[v*3+1] + M[10]*p.nrm[v*3+2];
            float nl = (float) Math.sqrt(nx*nx + ny*ny + nz*nz);
            if (nl < 1e-9f) nl = 1f;
            nx /= nl; ny /= nl; nz /= nl;
            float vx = -dx, vy = -dy, vz = -dz;
            float vl = 1f / (float) Math.sqrt(vx*vx + vy*vy + vz*vz);
            vx *= vl; vy *= vl; vz *= vl;
            float ndv = nx*vx + ny*vy + nz*vz;
            if (ndv < 0f && p.twoSided) { nx = -nx; ny = -ny; nz = -nz; ndv = -ndv; }
            float ndl1 = Math.max(0f, nx*l1x + ny*l1y + nz*l1z), ndl2 = Math.max(0f, nx*l2x + ny*l2y + nz*l2z);
            float diff = 0.40f + 0.20f * ny + 0.85f * ndl1 + 0.30f * ndl2;
            float br, bg, bb;
            if (textured) { br = tintR; bg = tintG; bb = tintB; }
            else if (paint) { br = pc[0]; bg = pc[1]; bb = pc[2]; }
            else { br = p.col[v*3]; bg = p.col[v*3+1]; bb = p.col[v*3+2]; }
            float rr = br * diff, gg = bg * diff, bl = bb * diff;
            float sr = 0f, sg2 = 0f, sb = 0f;
            if (spec > 0f) {
                float hx = l1x + vx, hy = l1y + vy, hz = l1z + vz;
                float hl = (float) Math.sqrt(hx*hx + hy*hy + hz*hz);
                if (hl > 1e-6f) {
                    float nh = Math.max(0f, (nx*hx + ny*hy + nz*hz) / hl);
                    float s = spec * pSq(nh, sq);
                    sr += s; sg2 += s; sb += s;
                }
            }
            if (env > 0f) {
                float k2 = 2f * Math.max(ndv, 0f);
                float rvx = k2*nx - vx, rvy = k2*ny - vy, rvz = k2*nz - vz;
                float er, eg, eb;
                if (rvy > 0f) {
                    float t = Math.min(1f, rvy * 1.6f);
                    er = 0.50f - 0.34f * t; eg = 0.54f - 0.32f * t; eb = 0.60f - 0.20f * t;
                } else {
                    float t = Math.min(1f, -rvy * 2.2f);
                    er = 0.16f - 0.13f * t; eg = 0.16f - 0.13f * t; eb = 0.18f - 0.14f * t;
                }
                float s1 = p16(Math.max(0f, 0.25f*rvx + 0.95f*rvy - 0.15f*rvz)) * 1.4f;
                float s2 = p16(Math.max(0f, -0.80f*rvx + 0.35f*rvy + 0.50f*rvz)) * 1.0f;
                float s3 = p16(Math.max(0f, 0.80f*rvx + 0.30f*rvy - 0.60f*rvz)) * 0.7f;
                float sbx = s1 + s2 + s3;
                float f1 = 1f - Math.max(ndv, 0f);
                f1 *= f1; f1 *= f1;
                float fres = 0.12f + 0.88f * f1;
                float e = env * fres;
                sr += (er + sbx) * e; sg2 += (eg + sbx) * e; sb += (eb + sbx) * e;
            }
            float ao = 1f;
            if (aoOn) {
                float t = (wy - 0.05f) / 0.55f;
                t = t < 0f ? 0f : (t > 1f ? 1f : t);
                ao = 0.50f + 0.50f * t * t * (3f - 2f * t);
            }
            float gl = 0f, gl2 = 0f, gl3 = 0f;
            if (p.glowAmt != 0f) { float gw = p.gw[v]; gl = gR * gw; gl2 = gG * gw; gl3 = gB * gw; }
            float fg = 0f;
            if (fogOn) { fg = (cz - 22f) / 170f; fg = fg < 0f ? 0f : (fg > 0.93f ? 0.93f : fg); }
            float k0 = 1f - fg;
            if (textured) {
                cr[v] = rr * ao * k0; cg[v] = gg * ao * k0; cb[v] = bl * ao * k0;
                ar[v] = (sr * ao + gl) * k0 + 0.020f * fg; ag[v] = (sg2 * ao + gl2) * k0 + 0.026f * fg; ab[v] = (sb * ao + gl3) * k0 + 0.045f * fg;
            } else {
                cr[v] = ((rr + sr) * ao + gl) * k0 + 0.020f * fg; cg[v] = ((gg + sg2) * ao + gl2) * k0 + 0.026f * fg; cb[v] = ((bl + sb) * ao + gl3) * k0 + 0.045f * fg;
            }
        }
        boolean ts = p.twoSided;
        float al = p.alpha;
        int[] t = p.tri;
        for (int i = 0; i < p.ni; i += 3) {
            int a = t[i], b = t[i+1], c = t[i+2];
            if (iz[a] < 0f || iz[b] < 0f || iz[c] < 0f) continue;
            if (!ts) {
                float area = (sx[b]-sx[a]) * (sy[c]-sy[a]) - (sx[c]-sx[a]) * (sy[b]-sy[a]);
                if (area >= 0f) continue;
            }
            if (textured) fillTriTex(a, b, c, blend, al, p.tex);
            else fillTri(a, b, c, blend, al);
        }
    }

    private void fillTriTex(int a, int b, int c, boolean blend, float alpha, Tex tex) {
        float x0 = sx[a], y0 = sy[a], x1 = sx[b], y1 = sy[b], x2 = sx[c], y2 = sy[c];
        float area = (x1 - x0) * (y2 - y0) - (x2 - x0) * (y1 - y0);
        if (area > -1e-6f && area < 1e-6f) return;
        float inv = 1f / area;
        int minX = Math.max(0, (int) Math.floor(Math.min(x0, Math.min(x1, x2))));
        int maxX = Math.min(fbW - 1, (int) Math.ceil(Math.max(x0, Math.max(x1, x2))));
        int minY = Math.max(0, (int) Math.floor(Math.min(y0, Math.min(y1, y2))));
        int maxY = Math.min(fbH - 1, (int) Math.ceil(Math.max(y0, Math.max(y1, y2))));
        if (minX > maxX || minY > maxY) return;
        float dw0 = (y1 - y2) * inv, dw1 = (y2 - y0) * inv;
        float iz0 = iz[a], iz1 = iz[b], iz2 = iz[c];
        float u0 = tu[a], u1 = tu[b], u2 = tu[c], v0 = tv[a], v1 = tv[b], v2 = tv[c];
        float r0 = cr[a], r1 = cr[b], r2 = cr[c], g0 = cg[a], g1 = cg[b], g2 = cg[c], b0 = cb[a], b1 = cb[b], b2 = cb[c];
        float qr0 = ar[a], qr1 = ar[b], qr2 = ar[c], qg0 = ag[a], qg1 = ag[b], qg2 = ag[c], qb0 = ab[a], qb1 = ab[b], qb2 = ab[c];
        int tw = tex.w, th = tex.h, mw = tw - 1, mh = th - 1;
        int[] tp = tex.px;
        float eps = -1e-4f, k255 = 1f / 255f;
        for (int y = minY; y <= maxY; y++) {
            float py = y + 0.5f, px = minX + 0.5f;
            float w0 = ((x1 - px) * (y2 - py) - (x2 - px) * (y1 - py)) * inv;
            float w1 = ((x2 - px) * (y0 - py) - (x0 - px) * (y2 - py)) * inv;
            int idx = y * fbW + minX;
            for (int x = minX; x <= maxX; x++, idx++, w0 += dw0, w1 += dw1) {
                float w2 = 1f - w0 - w1;
                if (w0 < eps || w1 < eps || w2 < eps) continue;
                float z = w0 * iz0 + w1 * iz1 + w2 * iz2;
                if (z <= zb[idx]) continue;
                float iu = 1f / z;
                float U = (w0 * u0 + w1 * u1 + w2 * u2) * iu, V = (w0 * v0 + w1 * v1 + w2 * v2) * iu;
                int tx = ((int) (U * tw + 65536f * tw)) & mw;
                int ty = ((int) ((1f - V) * th + 65536f * th)) & mh;
                int tc = tp[ty * tw + tx];
                float rr = ((tc >> 16) & 255) * k255 * (w0 * r0 + w1 * r1 + w2 * r2) + (w0 * qr0 + w1 * qr1 + w2 * qr2);
                float gg = ((tc >> 8) & 255) * k255 * (w0 * g0 + w1 * g1 + w2 * g2) + (w0 * qg0 + w1 * qg1 + w2 * qg2);
                float bl = (tc & 255) * k255 * (w0 * b0 + w1 * b1 + w2 * b2) + (w0 * qb0 + w1 * qb1 + w2 * qb2);
                int ri = rr <= 0f ? 0 : rr >= 1f ? 255 : (int) (rr * 255f);
                int gi = gg <= 0f ? 0 : gg >= 1f ? 255 : (int) (gg * 255f);
                int bi = bl <= 0f ? 0 : bl >= 1f ? 255 : (int) (bl * 255f);
                if (!blend) {
                    zb[idx] = z;
                    fb[idx] = 0xFF000000 | (ri << 16) | (gi << 8) | bi;
                } else {
                    int d = fb[idx];
                    int da = d >>> 24;
                    if (da == 0) fb[idx] = (((int) (alpha * 255f)) << 24) | (ri << 16) | (gi << 8) | bi;
                    else {
                        int dr = (d >> 16) & 255, dg = (d >> 8) & 255, db = d & 255;
                        int nr = (int) (ri * alpha + dr * (1f - alpha)), ng = (int) (gi * alpha + dg * (1f - alpha)), nb = (int) (bi * alpha + db * (1f - alpha));
                        fb[idx] = 0xFF000000 | (nr << 16) | (ng << 8) | nb;
                    }
                }
            }
        }
    }

    private void fillTri(int a, int b, int c, boolean blend, float alpha) {
        float x0 = sx[a], y0 = sy[a], x1 = sx[b], y1 = sy[b], x2 = sx[c], y2 = sy[c];
        float area = (x1 - x0) * (y2 - y0) - (x2 - x0) * (y1 - y0);
        if (area > -1e-6f && area < 1e-6f) return;
        float inv = 1f / area;
        int minX = Math.max(0, (int) Math.floor(Math.min(x0, Math.min(x1, x2))));
        int maxX = Math.min(fbW - 1, (int) Math.ceil(Math.max(x0, Math.max(x1, x2))));
        int minY = Math.max(0, (int) Math.floor(Math.min(y0, Math.min(y1, y2))));
        int maxY = Math.min(fbH - 1, (int) Math.ceil(Math.max(y0, Math.max(y1, y2))));
        if (minX > maxX || minY > maxY) return;
        float dw0 = (y1 - y2) * inv, dw1 = (y2 - y0) * inv;
        float iz0 = iz[a], iz1 = iz[b], iz2 = iz[c];
        float r0 = cr[a], r1 = cr[b], r2 = cr[c], g0 = cg[a], g1 = cg[b], g2 = cg[c], b0 = cb[a], b1 = cb[b], b2 = cb[c];
        float eps = -1e-4f;
        for (int y = minY; y <= maxY; y++) {
            float py = y + 0.5f, px = minX + 0.5f;
            float w0 = ((x1 - px) * (y2 - py) - (x2 - px) * (y1 - py)) * inv;
            float w1 = ((x2 - px) * (y0 - py) - (x0 - px) * (y2 - py)) * inv;
            int idx = y * fbW + minX;
            for (int x = minX; x <= maxX; x++, idx++, w0 += dw0, w1 += dw1) {
                float w2 = 1f - w0 - w1;
                if (w0 < eps || w1 < eps || w2 < eps) continue;
                float z = w0 * iz0 + w1 * iz1 + w2 * iz2;
                if (z <= zb[idx]) continue;
                float rr = w0 * r0 + w1 * r1 + w2 * r2, gg = w0 * g0 + w1 * g1 + w2 * g2, bl = w0 * b0 + w1 * b1 + w2 * b2;
                int ri = rr <= 0f ? 0 : rr >= 1f ? 255 : (int) (rr * 255f);
                int gi = gg <= 0f ? 0 : gg >= 1f ? 255 : (int) (gg * 255f);
                int bi = bl <= 0f ? 0 : bl >= 1f ? 255 : (int) (bl * 255f);
                if (!blend) {
                    zb[idx] = z;
                    fb[idx] = 0xFF000000 | (ri << 16) | (gi << 8) | bi;
                } else {
                    int d = fb[idx];
                    int da = d >>> 24;
                    if (curAdd) {
                        if (ri + gi + bi < 3) continue;
                        addLight(idx, ri, gi, bi);
                    } else if (da == 0) fb[idx] = (((int) (alpha * 255f)) << 24) | (ri << 16) | (gi << 8) | bi;
                    else {
                        int dr = (d >> 16) & 255, dg = (d >> 8) & 255, db = d & 255;
                        int nr = (int) (ri * alpha + dr * (1f - alpha)), ng = (int) (gi * alpha + dg * (1f - alpha)), nb = (int) (bi * alpha + db * (1f - alpha));
                        fb[idx] = 0xFF000000 | (nr << 16) | (ng << 8) | nb;
                    }
                }
            }
        }
    }

    /** Добавить свет к пикселю: поверх геометрии — прибавить цвет, на прозрачном фоне — копить яркость и прозрачность. */
    private void addLight(int idx, int ri, int gi, int bi) {
        int d = fb[idx];
        int da = d >>> 24;
        int nr = Math.min(255, ((d >> 16) & 255) + ri), ng = Math.min(255, ((d >> 8) & 255) + gi), nb = Math.min(255, (d & 255) + bi);
        if (da == 255) fb[idx] = 0xFF000000 | (nr << 16) | (ng << 8) | nb;
        else {
            if (da == 0) { nr = Math.min(255, ri); ng = Math.min(255, gi); nb = Math.min(255, bi); }
            int na = Math.min(255, Math.max(da, Math.max(nr, Math.max(ng, nb))));
            fb[idx] = (na << 24) | (nr << 16) | (ng << 8) | nb;
        }
    }

    /** Блик вокруг фары (виден только спереди/сзади, закрывается кузовом). */
    private void glare(float[] local, float dirZ, float cR, float cG, float cB, float radiusM, float inten) {
        float[] M = mbody;
        float wx = M[0]*local[0] + M[1]*local[1] + M[2]*local[2] + M[3];
        float wy = M[4]*local[0] + M[5]*local[1] + M[6]*local[2] + M[7];
        float wz = M[8]*local[0] + M[9]*local[1] + M[10]*local[2] + M[11];
        glareW(wx, wy, wz, radiusM, dirZ, cR, cG, cB, inten);
    }

    /** Блик в мировых координатах; dirZ=0 — светит во все стороны. */
    private void glareW(float wx, float wy, float wz, float radiusM, float dirZ, float cR, float cG, float cB, float inten) {
        float dx = wx - ex, dy = wy - ey, dz = wz - ez;
        float cz = dx*fx + dy*fy + dz*fz;
        if (cz < 0.6f) return;
        float dl = (float) Math.sqrt(dx*dx + dy*dy + dz*dz);
        float facing = dirZ == 0f ? 1f : (-dz / dl) * dirZ;
        if (facing <= 0.05f) return;
        float k = inten * facing * facing;
        if (k < 0.02f) return;
        float cxv = dx*rx + dy*ry + dz*rz, cyv = dx*ux + dy*uy + dz*uz;
        float px = fbW * 0.5f + foc * cxv / cz, py = fbH * 0.5f - foc * cyv / cz;
        float rad = foc * radiusM / cz;
        if (rad < 2f) return;
        float izH = 1f / cz;
        int x0 = Math.max(0, (int) (px - rad)), x1 = Math.min(fbW - 1, (int) (px + rad));
        int y0 = Math.max(0, (int) (py - rad)), y1 = Math.min(fbH - 1, (int) (py + rad));
        float inv2 = 1f / (rad * rad);
        for (int y = y0; y <= y1; y++) {
            for (int x = x0; x <= x1; x++) {
                float ddx = x + 0.5f - px, ddy = y + 0.5f - py;
                float f = 1f - (ddx * ddx + ddy * ddy) * inv2;
                if (f <= 0f) continue;
                int idx = y * fbW + x;
                if (zb[idx] > izH * 1.12f) continue;
                f = f * f * k;
                int ri = (int) (255f * cR * f), gi = (int) (255f * cG * f), bi = (int) (255f * cB * f);
                addLight(idx, ri, gi, bi);
            }
        }
    }


    private static float hash(float x) {
        float v = (float) Math.sin(x * 12.9898f) * 43758.5453f;
        return v - (float) Math.floor(v);
    }

    private void blendPx(int x, int y, float r, float g, float b, float a) {
        if (x < 0 || y < 0 || x >= fbW || y >= fbH) return;
        int idx = y * fbW + x, d = fb[idx];
        int dr = (d >> 16) & 255, dg = (d >> 8) & 255, db = d & 255;
        int nr = (int) (dr + (r * 255f - dr) * a), ng = (int) (dg + (g * 255f - dg) * a), nb = (int) (db + (b * 255f - db) * a);
        fb[idx] = 0xFF000000 | (nr << 16) | (ng << 8) | nb;
    }

    /** Дождь и снег поверх кадра (экранные частицы). */
    private void weather() {
        float sc = fbH / 540f;
        float spd = Math.min(1f, speedKmh / 160f);
        if (rain) {
            int n = 320;
            for (int i = 0; i < n; i++) {
                float h1 = hash(i * 1.37f), h2 = hash(i * 7.71f + 3f), h3 = hash(i * 3.13f + 9f);
                float x = h1 * (fbW + 80) - 40;
                float y = ((h2 + time * (1.5f + 0.9f * h3)) % 1f) * (fbH + 80) - 40;
                float len = (16f + 24f * h3) * sc * (1f + spd);
                float slant = (0.10f + 0.65f * spd) * len;
                float a = 0.20f + 0.22f * h3;
                int steps = (int) Math.max(2f, len);
                for (int k = 0; k < steps; k++) {
                    float t = (float) k / steps;
                    blendPx((int) (x - slant * t), (int) (y - len * t), 0.72f, 0.80f, 0.95f, a * (1f - 0.6f * t));
                }
            }
        }
        if (snow) {
            int n = 260;
            for (int i = 0; i < n; i++) {
                float h1 = hash(i * 2.11f + 5f), h2 = hash(i * 5.29f + 1f), h3 = hash(i * 9.07f + 2f);
                float x = ((h1 + time * 0.03f * (h3 - 0.5f) + (float) Math.sin(time * 0.8f + i) * 0.01f) % 1f + 1f) % 1f * fbW;
                float y = ((h2 + time * (0.05f + 0.09f * h3)) % 1f) * fbH;
                float rad = (1.1f + 2.3f * h3 * h3) * sc;
                int x0 = (int) (x - rad), x1 = (int) (x + rad), y0 = (int) (y - rad), y1 = (int) (y + rad);
                for (int yy = y0; yy <= y1; yy++) for (int xx = x0; xx <= x1; xx++) {
                    float dx = xx + 0.5f - x, dy = yy + 0.5f - y;
                    float q = 1f - (dx * dx + dy * dy) / (rad * rad);
                    if (q > 0f) blendPx(xx, yy, 0.95f, 0.97f, 1f, 0.85f * q);
                }
            }
        }
    }

    private int[] fxTmp = new int[0];

    /** Лёгкое сглаживание краёв (когда рисуем без суперсэмплинга). */
    private void fxaa(int[] o, int w, int h) {
        if (fxTmp.length != o.length) fxTmp = new int[o.length];
        System.arraycopy(o, 0, fxTmp, 0, o.length);
        int[] s = fxTmp;
        for (int y = 1; y < h - 1; y++) {
            int row = y * w;
            for (int x = 1; x < w - 1; x++) {
                int i = row + x;
                int c = s[i], n = s[i - w], so = s[i + w], e = s[i + 1], we = s[i - 1];
                int lc = ((c >> 16 & 255) * 77 + (c >> 8 & 255) * 150 + (c & 255) * 29) >> 8;
                int ln = ((n >> 16 & 255) * 77 + (n >> 8 & 255) * 150 + (n & 255) * 29) >> 8;
                int ls = ((so >> 16 & 255) * 77 + (so >> 8 & 255) * 150 + (so & 255) * 29) >> 8;
                int le = ((e >> 16 & 255) * 77 + (e >> 8 & 255) * 150 + (e & 255) * 29) >> 8;
                int lw = ((we >> 16 & 255) * 77 + (we >> 8 & 255) * 150 + (we & 255) * 29) >> 8;
                int mx = Math.max(lc, Math.max(Math.max(ln, ls), Math.max(le, lw)));
                int mn = Math.min(lc, Math.min(Math.min(ln, ls), Math.min(le, lw)));
                if (mx - mn < 28) continue;
                int r = ((c >> 16 & 255) * 2 + (n >> 16 & 255) + (so >> 16 & 255) + (e >> 16 & 255) + (we >> 16 & 255)) / 6;
                int g = ((c >> 8 & 255) * 2 + (n >> 8 & 255) + (so >> 8 & 255) + (e >> 8 & 255) + (we >> 8 & 255)) / 6;
                int b = ((c & 255) * 2 + (n & 255) + (so & 255) + (e & 255) + (we & 255)) / 6;
                o[i] = 0xFF000000 | (r << 16) | (g << 8) | b;
            }
        }
    }
}
