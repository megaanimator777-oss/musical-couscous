package com.musicviz.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.audiofx.BassBoost
import android.media.audiofx.DynamicsProcessing
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Visualizer
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import com.musicviz.engine.Scene3D
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sqrt

/**
 * Слушает звук любого плеера, включает системные аудиоэффекты («саб в багажнике»)
 * и анимирует виджет на рабочем столе.
 */
class AudioService : Service() {

    companion object {
        const val ACTION_STOP = "com.musicviz.app.STOP"
        private const val CHANNEL = "musicviz"
        private const val NOTIF_ID = 77
    }

    private lateinit var prefs: SharedPreferences
    private val analyzer = Analyzer()

    private var visualizer: Visualizer? = null
    private var projection: MediaProjection? = null
    private var recorder: AudioRecord? = null
    private var captureThread: Thread? = null
    @Volatile private var capturing = false

    private var bassBoost: BassBoost? = null
    private var equalizer: Equalizer? = null
    private var loudness: LoudnessEnhancer? = null
    private var dynProc: Any? = null

    private var widgetThread: Thread? = null
    @Volatile private var widgetRun = false

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == Prefs.SUB_ON || key == Prefs.POWER || key == Prefs.MUFFLE || key == Prefs.GAIN) applyEffects()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        AssetsInit.ensure(this)
        prefs = Prefs.get(this)
        prefs.registerOnSharedPreferenceChangeListener(prefListener)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        val mode = intent?.getIntExtra("mode", 0) ?: 0
        val useProjection = mode == 1 && Build.VERSION.SDK_INT >= 29

        createChannel()
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            val type = if (useProjection) {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            } else {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
            }
            startForeground(NOTIF_ID, notification, type)
        } else {
            startForeground(NOTIF_ID, notification)
        }

        releaseCapture()
        AudioBus.error = null
        AudioBus.lastSignal = System.currentTimeMillis()
        AudioBus.running = true

        if (useProjection) {
            val code = intent?.getIntExtra("code", 0) ?: 0
            val data = intent?.getParcelableExtra<Intent>("data")
            if (data == null) {
                AudioBus.error = "Нет разрешения на запись звука. Нажми «Старт» ещё раз."
            } else {
                startPlaybackCapture(code, data)
            }
        } else {
            startVisualizer()
        }
        applyEffects()
        startWidgetLoop()
        return START_NOT_STICKY
    }

    // ---------- Захват звука: способ 1 — системный микшер ----------

    private fun startVisualizer() {
        try {
            val v = Visualizer(0)
            v.setEnabled(false)
            val range = Visualizer.getCaptureSizeRange()
            v.setCaptureSize(range[1])
            v.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(vis: Visualizer?, waveform: ByteArray?, samplingRate: Int) {}
                override fun onFftDataCapture(vis: Visualizer?, fft: ByteArray?, samplingRate: Int) {
                    if (fft != null) handleFft(fft, samplingRate)
                }
            }, Visualizer.getMaxCaptureRate(), false, true)
            v.setEnabled(true)
            visualizer = v
        } catch (e: Exception) {
            AudioBus.error = "Этот телефон не отдаёт системный звук. Выбери метод «Запись воспроизведения» в настройках."
        }
    }

    private fun handleFft(fft: ByteArray, samplingRate: Int) {
        val n = fft.size
        val bins = n / 2
        val mags = FloatArray(bins)
        mags[0] = Math.abs(fft[0].toInt()) / 128f
        for (k in 1 until bins) {
            val re = fft[2 * k].toInt()
            val im = fft[2 * k + 1].toInt()
            mags[k] = sqrt((re * re + im * im).toFloat()) / 128f
        }
        val binHz = (samplingRate / 1000f) / n
        analyzer.push(mags, binHz)
    }

    // ---------- Захват звука: способ 2 — запись воспроизведения (Android 10+) ----------

    private fun startPlaybackCapture(code: Int, data: Intent) {
        try {
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val p = mpm.getMediaProjection(code, data)
            projection = p
            p.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    stopSelf()
                }
            }, Handler(Looper.getMainLooper()))

            val cfg = AudioPlaybackCaptureConfiguration.Builder(p)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()
            val fmt = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(44100)
                .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                .build()
            val minBuf = AudioRecord.getMinBufferSize(
                44100, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT
            )
            val rec = AudioRecord.Builder()
                .setAudioPlaybackCaptureConfig(cfg)
                .setAudioFormat(fmt)
                .setBufferSizeInBytes(maxOf(minBuf, 16384))
                .build()
            rec.startRecording()
            recorder = rec
            capturing = true

            captureThread = Thread {
                val n = 2048
                val hop = 1024
                val window = FloatArray(n)
                val hann = FloatArray(n) { (0.5 - 0.5 * cos(2.0 * PI * it / (n - 1))).toFloat() }
                val buf = ShortArray(hop * 2)
                val re = FloatArray(n)
                val im = FloatArray(n)
                val mags = FloatArray(n / 2)
                while (capturing) {
                    val read = rec.read(buf, 0, buf.size)
                    if (read < 0) break
                    if (read == 0) continue
                    val frames = read / 2
                    System.arraycopy(window, frames, window, 0, n - frames)
                    for (i in 0 until frames) {
                        window[n - frames + i] = (buf[2 * i] + buf[2 * i + 1]) / 65536f
                    }
                    for (i in 0 until n) {
                        re[i] = window[i] * hann[i]
                        im[i] = 0f
                    }
                    Fft.transform(re, im)
                    for (k in 0 until n / 2) {
                        mags[k] = sqrt(re[k] * re[k] + im[k] * im[k]) * 4f / n
                    }
                    analyzer.push(mags, 44100f / n)
                }
            }.also {
                it.isDaemon = true
                it.start()
            }
        } catch (e: Exception) {
            AudioBus.error = "Не удалось начать запись воспроизведения: ${e.message}"
        }
    }

    // ---------- «Саб в багажнике»: системные аудиоэффекты ----------

    private fun applyEffects() {
        if (!prefs.getBoolean(Prefs.SUB_ON, false)) {
            releaseEffects()
            return
        }
        val power = prefs.getInt(Prefs.POWER, 85) / 100f
        val muffle = prefs.getInt(Prefs.MUFFLE, 55) / 100f
        val gain = prefs.getInt(Prefs.GAIN, 40) / 100f

        try {
            val bb = bassBoost ?: BassBoost(100, 0).also { bassBoost = it }
            if (bb.getStrengthSupported()) bb.setStrength((power * 1000f).toInt().toShort())
            bb.setEnabled(true)
        } catch (e: Exception) {
            bassBoost = null
        }

        try {
            val eq = equalizer ?: Equalizer(100, 0).also { equalizer = it }
            val range = eq.getBandLevelRange()
            val lo = range[0].toInt()
            val hi = range[1].toInt()
            for (b in 0 until eq.getNumberOfBands()) {
                val f = eq.getCenterFreq(b.toShort()) / 1000
                val level: Float = when {
                    f < 120 -> hi * power
                    f < 350 -> hi * 0.75f * power
                    f < 1000 -> lo * 0.25f * muffle
                    f < 4000 -> lo * 0.70f * muffle
                    else -> lo * muffle
                }
                eq.setBandLevel(b.toShort(), level.toInt().coerceIn(lo, hi).toShort())
            }
            eq.setEnabled(true)
        } catch (e: Exception) {
            equalizer = null
        }

        try {
            val le = loudness ?: LoudnessEnhancer(0).also { loudness = it }
            le.setTargetGain((gain * 800f).toInt())
            le.setEnabled(true)
        } catch (e: Exception) {
            loudness = null
        }

        applyDynamics(power, muffle)
    }

    private fun applyDynamics(power: Float, muffle: Float) {
        if (Build.VERSION.SDK_INT < 28) return
        try {
            var dp = dynProc as DynamicsProcessing?
            if (dp == null) {
                val cfg = DynamicsProcessing.Config.Builder(
                    DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION, 2,
                    true, 6, false, 0, false, 0, true
                ).build()
                dp = DynamicsProcessing(100, 0, cfg)
                dynProc = dp
            }
            val cut = floatArrayOf(45f, 90f, 180f, 500f, 2500f, 9000f)
            val g = floatArrayOf(14f * power, 11f * power, 5f * power, 0f, -9f * muffle, -16f * muffle)
            for (i in 0 until 6) {
                dp.setPreEqBandAllChannelsTo(i, DynamicsProcessing.EqBand(true, cut[i], g[i]))
            }
            dp.setInputGainAllChannelsTo(-4f * power)
            dp.setLimiterAllChannelsTo(DynamicsProcessing.Limiter(true, true, 0, 1f, 60f, 10f, -2f, 0f))
            dp.setEnabled(true)
        } catch (e: Throwable) {
            dynProc = null
        }
    }

    private fun releaseEffects() {
        try { bassBoost?.release() } catch (e: Exception) {}
        try { equalizer?.release() } catch (e: Exception) {}
        try { loudness?.release() } catch (e: Exception) {}
        if (Build.VERSION.SDK_INT >= 28) {
            try { (dynProc as DynamicsProcessing?)?.release() } catch (e: Throwable) {}
        }
        bassBoost = null
        equalizer = null
        loudness = null
        dynProc = null
    }

    // ---------- Виджет: анимация, пока играет музыка ----------

    private fun startWidgetLoop() {
        if (widgetRun) return
        widgetRun = true
        widgetThread = Thread {
            try {
                val awm = AppWidgetManager.getInstance(this)
                var scene: Scene3D? = null
                var last = System.nanoTime()
                while (widgetRun) {
                    val ids = Widgets.ids(this)
                    if (ids.isEmpty()) {
                        Thread.sleep(1000)
                        continue
                    }
                    if (scene == null) scene = Scene3D()
                    SceneConfig.apply(scene, prefs, true)
                    scene.pitch = 0.26f
                    scene.dist = 5.2f
                    val now = System.nanoTime()
                    val dt = ((now - last) / 1e9f).coerceIn(0.001f, 0.1f)
                    last = now
                    scene.step(dt, AudioBus.bass, AudioBus.bands, prefs.getInt(Prefs.SENS, 100) / 100f)
                    scene.yaw += dt * 0.30f
                    for (id in ids) {
                        try {
                            Widgets.push(this, awm, id, scene)
                        } catch (e: Throwable) {
                        }
                    }
                    Thread.sleep(70)
                }
            } catch (e: InterruptedException) {
            } catch (e: Throwable) {
            }
        }.also {
            it.isDaemon = true
            it.start()
        }
    }

    private fun stopWidgetLoop() {
        widgetRun = false
        widgetThread?.interrupt()
        widgetThread = null
    }

    // ---------- Служебное ----------

    private fun releaseCapture() {
        capturing = false
        try { visualizer?.setEnabled(false) } catch (e: Exception) {}
        try { visualizer?.release() } catch (e: Exception) {}
        visualizer = null
        try { recorder?.stop() } catch (e: Exception) {}
        try { captureThread?.join(400) } catch (e: Exception) {}
        try { recorder?.release() } catch (e: Exception) {}
        recorder = null
        captureThread = null
        try { projection?.stop() } catch (e: Exception) {}
        projection = null
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "MusicViz", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun buildNotification(): Notification {
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, AudioService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("MusicViz")
            .setContentText("Слушаю музыку из любого плеера")
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(0, "Стоп", stop).build())
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
        stopWidgetLoop()
        releaseCapture()
        releaseEffects()
        AudioBus.running = false
        AudioBus.reset()
        stopForeground(true)
        // вернуть виджет в статичное состояние
        try {
            val ids = Widgets.ids(this)
            if (ids.isNotEmpty()) {
                val i = Intent(AppWidgetManager.ACTION_APPWIDGET_UPDATE)
                i.component = ComponentName(this, CarWidget::class.java)
                i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
                sendBroadcast(i)
            }
        } catch (e: Exception) {}
        super.onDestroy()
    }
}
