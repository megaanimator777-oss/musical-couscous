package com.musicviz.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle

/** Невидимая «кнопка» для виджета: старт/стоп без открытия приложения. */
class StartActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = Prefs.get(this)
        if (AudioBus.running) {
            stopService(Intent(this, AudioService::class.java))
        } else {
            val granted = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            if (granted && prefs.getInt(Prefs.METHOD, 0) == 0) {
                val i = Intent(this, AudioService::class.java)
                i.putExtra("mode", 0)
                startForegroundService(i)
            } else {
                val i = Intent(this, MainActivity::class.java)
                i.putExtra("autostart", true)
                startActivity(i)
            }
        }
        finish()
    }
}
