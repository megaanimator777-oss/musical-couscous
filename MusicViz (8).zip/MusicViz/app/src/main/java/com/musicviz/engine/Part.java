package com.musicviz.engine;

import java.util.Arrays;

/** Кусок сетки с общим материалом. */
public final class Part {
    float[] pos = new float[192], nrm = new float[192], col = new float[192];
    float[] gw = new float[64], dw = new float[64];
    int[] tri = new int[192];
    int nv = 0, ni = 0;

    float spec = 0.15f, shin = 30f, env = 0.05f;
    boolean twoSided, paint;
    int glowKind;            // 0 нет, 1 акцент, 2 стоп-сигнал, 3 фара, 4 волна, 5 пол, 6 эквалайзер
    float[] glowCol = new float[3];
    float glowAmt;
    int deform;              // 1 = ход диффузора
    int group;               // 0 мир, 1 кузов, 2 крышка багажника, 3 волна, 4 столбик
    float[] base = Mat.id();
    float[] m = Mat.id();
    float alpha = 1f;        // 1 = непрозрачный; <1 — стекло
    int axis;                // 0 нет, 1 — вокруг Y (дверь), 2 — вокруг X (крышка/дверь багажника)
    int ctrl;                // 1 двери, 2 багажник
    float[] pivot = new float[3];
    float maxAng, dir = 1f;
    String tag = "";
    float[] uv;              // для текстурированных деталей: 2 числа на вершину
    Tex tex;                 // текстура (null — без текстуры)
    boolean tintPaint;       // умножать текстуру на цвет кузова
    boolean additive;        // свет: добавляется к картинке (лучи фар)
    boolean road;            // деталь дороги (видна только в режимах «дорога» и «салон»)
    float period;            // для бесконечной дороги: период повторения, м

    private void grow(int addV, int addI) {
        int needV = nv + addV;
        if (needV * 3 > pos.length) {
            int n = Math.max(pos.length * 2, needV * 3);
            pos = Arrays.copyOf(pos, n); nrm = Arrays.copyOf(nrm, n); col = Arrays.copyOf(col, n);
            gw = Arrays.copyOf(gw, n / 3); dw = Arrays.copyOf(dw, n / 3);
        }
        if (ni + addI > tri.length) tri = Arrays.copyOf(tri, Math.max(tri.length * 2, ni + addI));
    }

    void tri(int a) {
        grow(0, 3);
        tri[ni++] = a;
    }

    int vtx(float x, float y, float z, float nx, float ny, float nz, float r, float g, float b, float gwt, float dwt) {
        grow(1, 0);
        int i = nv++;
        pos[i*3] = x; pos[i*3+1] = y; pos[i*3+2] = z;
        nrm[i*3] = nx; nrm[i*3+1] = ny; nrm[i*3+2] = nz;
        col[i*3] = r; col[i*3+1] = g; col[i*3+2] = b;
        gw[i] = gwt; dw[i] = dwt;
        return i;
    }

    void tri(int a, int b, int c) {
        grow(0, 3);
        tri[ni++] = a; tri[ni++] = b; tri[ni++] = c;
    }

    /** Сетка p[nu][nv][3]; нормали считаются по разностям. flip — перевернуть наружу. */
    void grid(float[][][] p, boolean closedU, boolean flip, boolean[][] skip,
              float[] rgb, float[][] gwArr, float[][] dwArr) {
        int nu = p.length, nvv = p[0].length;
        int base0 = nv;
        grow(nu * nvv, (nu - 1) * (nvv - 1) * 6);
        for (int i = 0; i < nu; i++) {
            for (int j = 0; j < nvv; j++) {
                int i0 = closedU ? (i == 0 ? nu - 2 : i - 1) : Math.max(i - 1, 0);
                int i1 = closedU ? (i == nu - 1 ? 1 : i + 1) : Math.min(i + 1, nu - 1);
                int j0 = Math.max(j - 1, 0), j1 = Math.min(j + 1, nvv - 1);
                float ux = p[i1][j][0] - p[i0][j][0], uy = p[i1][j][1] - p[i0][j][1], uz = p[i1][j][2] - p[i0][j][2];
                float vx = p[i][j1][0] - p[i][j0][0], vy = p[i][j1][1] - p[i][j0][1], vz = p[i][j1][2] - p[i][j0][2];
                float nx, ny, nz;
                if (flip) { nx = vy*uz - vz*uy; ny = vz*ux - vx*uz; nz = vx*uy - vy*ux; }
                else      { nx = uy*vz - uz*vy; ny = uz*vx - ux*vz; nz = ux*vy - uy*vx; }
                float l = (float)Math.sqrt(nx*nx + ny*ny + nz*nz);
                if (l < 1e-12f) { nx = 0; ny = 1; nz = 0; } else { nx /= l; ny /= l; nz /= l; }
                vtx(p[i][j][0], p[i][j][1], p[i][j][2], nx, ny, nz, rgb[0], rgb[1], rgb[2],
                    gwArr == null ? 0f : gwArr[i][j], dwArr == null ? 0f : dwArr[i][j]);
            }
        }
        for (int i = 0; i < nu - 1; i++) {
            for (int j = 0; j < nvv - 1; j++) {
                if (skip != null && skip[i][j]) continue;
                int a = base0 + i * nvv + j, b = base0 + (i + 1) * nvv + j;
                int c = base0 + (i + 1) * nvv + j + 1, d = base0 + i * nvv + j + 1;
                if (flip) { tri(a, c, b); tri(a, d, c); } else { tri(a, b, c); tri(a, c, d); }
            }
        }
    }

    void grid(float[][][] p, boolean flip, boolean[][] skip, float[] rgb) { grid(p, false, flip, skip, rgb, null, null); }

    /** Плоский четырёхугольник a,b,c,d (против часовой со стороны нормали). */
    void quad(float[] a, float[] b, float[] c, float[] d, float[] rgb, float gwt) {
        float ux = b[0]-a[0], uy = b[1]-a[1], uz = b[2]-a[2];
        float vx = c[0]-a[0], vy = c[1]-a[1], vz = c[2]-a[2];
        float nx = uy*vz - uz*vy, ny = uz*vx - ux*vz, nz = ux*vy - uy*vx;
        float l = (float)Math.sqrt(nx*nx + ny*ny + nz*nz);
        if (l < 1e-12f) return;
        nx /= l; ny /= l; nz /= l;
        int i0 = vtx(a[0],a[1],a[2],nx,ny,nz,rgb[0],rgb[1],rgb[2],gwt,0);
        int i1 = vtx(b[0],b[1],b[2],nx,ny,nz,rgb[0],rgb[1],rgb[2],gwt,0);
        int i2 = vtx(c[0],c[1],c[2],nx,ny,nz,rgb[0],rgb[1],rgb[2],gwt,0);
        int i3 = vtx(d[0],d[1],d[2],nx,ny,nz,rgb[0],rgb[1],rgb[2],gwt,0);
        tri(i0, i1, i2); tri(i0, i2, i3);
    }

    void quad(float[] a, float[] b, float[] c, float[] d, float[] rgb) { quad(a, b, c, d, rgb, 0f); }

    /** Прямоугольник в плоскости z=const, нормаль наружу вдоль nzSign. */
    void rectZ(float x0, float x1, float y0, float y1, float z, int nzSign, float[] rgb, float gwt) {
        if (nzSign < 0) quad(new float[]{x1,y0,z}, new float[]{x0,y0,z}, new float[]{x0,y1,z}, new float[]{x1,y1,z}, rgb, gwt);
        else quad(new float[]{x0,y0,z}, new float[]{x1,y0,z}, new float[]{x1,y1,z}, new float[]{x0,y1,z}, rgb, gwt);
    }

    /** Ящик с плоскими гранями. gTop/gBot — вес свечения верха/низа. */
    void box(float cx, float cy, float cz, float hx, float hy, float hz, float[] rgb, float gBot, float gTop) {
        float x0=cx-hx, x1=cx+hx, y0=cy-hy, y1=cy+hy, z0=cz-hz, z1=cz+hz;
        // +x
        quadG(new float[]{x1,y0,z1}, new float[]{x1,y0,z0}, new float[]{x1,y1,z0}, new float[]{x1,y1,z1}, rgb, gBot, gTop);
        // -x
        quadG(new float[]{x0,y0,z0}, new float[]{x0,y0,z1}, new float[]{x0,y1,z1}, new float[]{x0,y1,z0}, rgb, gBot, gTop);
        // +y
        quadG(new float[]{x0,y1,z1}, new float[]{x1,y1,z1}, new float[]{x1,y1,z0}, new float[]{x0,y1,z0}, rgb, gTop, gTop);
        // -y
        quadG(new float[]{x0,y0,z0}, new float[]{x1,y0,z0}, new float[]{x1,y0,z1}, new float[]{x0,y0,z1}, rgb, gBot, gBot);
        // +z
        quadG(new float[]{x0,y0,z1}, new float[]{x1,y0,z1}, new float[]{x1,y1,z1}, new float[]{x0,y1,z1}, rgb, gBot, gTop);
        // -z
        quadG(new float[]{x1,y0,z0}, new float[]{x0,y0,z0}, new float[]{x0,y1,z0}, new float[]{x1,y1,z0}, rgb, gBot, gTop);
    }

    private void quadG(float[] a, float[] b, float[] c, float[] d, float[] rgb, float gLow, float gHigh) {
        float ux = b[0]-a[0], uy = b[1]-a[1], uz = b[2]-a[2];
        float vx = c[0]-a[0], vy = c[1]-a[1], vz = c[2]-a[2];
        float nx = uy*vz - uz*vy, ny = uz*vx - ux*vz, nz = ux*vy - uy*vx;
        float l = (float)Math.sqrt(nx*nx + ny*ny + nz*nz);
        nx /= l; ny /= l; nz /= l;
        int i0 = vtx(a[0],a[1],a[2],nx,ny,nz,rgb[0],rgb[1],rgb[2],gLow,0);
        int i1 = vtx(b[0],b[1],b[2],nx,ny,nz,rgb[0],rgb[1],rgb[2],gLow,0);
        int i2 = vtx(c[0],c[1],c[2],nx,ny,nz,rgb[0],rgb[1],rgb[2],gHigh,0);
        int i3 = vtx(d[0],d[1],d[2],nx,ny,nz,rgb[0],rgb[1],rgb[2],gHigh,0);
        tri(i0, i1, i2); tri(i0, i2, i3);
    }

    /** Тело вращения вокруг локальной оси z. prof[j] = {r, u, deformWeight, glowWeight}. */
    void revolve(float[][] prof, int seg, boolean flip, float[] rgb) {
        int n = prof.length;
        float[][][] p = new float[seg + 1][n][3];
        float[][] dwA = new float[seg + 1][n];
        float[][] gwA = new float[seg + 1][n];
        for (int i = 0; i <= seg; i++) {
            double a = 2 * Math.PI * i / seg;
            float c = (float)Math.cos(a), s = (float)Math.sin(a);
            for (int j = 0; j < n; j++) {
                float r = Math.max(prof[j][0], 0.0008f);
                p[i][j][0] = r * c; p[i][j][1] = r * s; p[i][j][2] = prof[j][1];
                dwA[i][j] = prof[j][2];
                gwA[i][j] = prof.length > 0 && prof[j].length > 3 ? prof[j][3] : 0f;
            }
        }
        grid(p, true, flip, null, rgb, gwA, dwA);
    }

    /** Применить матрицу к вершинам, добавленным начиная с v0 (позиции и нормали). */
    void xform(int v0, float[] M) {
        for (int i = v0; i < nv; i++) {
            float x = pos[i*3], y = pos[i*3+1], z = pos[i*3+2];
            pos[i*3]   = M[0]*x + M[1]*y + M[2]*z + M[3];
            pos[i*3+1] = M[4]*x + M[5]*y + M[6]*z + M[7];
            pos[i*3+2] = M[8]*x + M[9]*y + M[10]*z + M[11];
            float nx = nrm[i*3], ny = nrm[i*3+1], nz = nrm[i*3+2];
            nrm[i*3]   = M[0]*nx + M[1]*ny + M[2]*nz;
            nrm[i*3+1] = M[4]*nx + M[5]*ny + M[6]*nz;
            nrm[i*3+2] = M[8]*nx + M[9]*ny + M[10]*nz;
        }
    }

    /** Вес свечения по расстоянию до точки (для света в салоне). */
    void glowByPoint(float cx, float cy, float cz, float radius, float min) {
        for (int i = 0; i < nv; i++) {
            float dx = pos[i*3]-cx, dy = pos[i*3+1]-cy, dz = pos[i*3+2]-cz;
            float d = (float)Math.sqrt(dx*dx+dy*dy+dz*dz);
            gw[i] = Math.max(min, 1f - d / radius);
        }
    }

    void shift(float dx, float dy, float dz) {
        for (int i = 0; i < nv; i++) { pos[i*3] += dx; pos[i*3+1] += dy; pos[i*3+2] += dz; }
    }

    /** Добавить вершину с UV (для моделей из файла); индекс треугольника добавляет вызывающий. */
    int addRaw(float x, float y, float z, float nx, float ny, float nz, float u, float v) {
        grow(1, 0);
        int i = nv++;
        pos[i*3] = x; pos[i*3+1] = y; pos[i*3+2] = z;
        nrm[i*3] = nx; nrm[i*3+1] = ny; nrm[i*3+2] = nz;
        if (uv == null || uv.length < nv * 2) uv = Arrays.copyOf(uv == null ? new float[0] : uv, Math.max(nv * 2, (uv == null ? 0 : uv.length) * 2));
        uv[i*2] = u; uv[i*2+1] = v;
        gw[i] = 0f; dw[i] = 0f;
        return i;
    }
}
